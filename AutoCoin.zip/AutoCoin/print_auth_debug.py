from utils.bithumb_api import API_KEY, API_SECRET

print("🔐 API_KEY =", API_KEY)
print("🔐 API_SECRET =", API_SECRET[:10] + "..." + API_SECRET[-10:])
print("🔐 길이 =", len(API_SECRET))

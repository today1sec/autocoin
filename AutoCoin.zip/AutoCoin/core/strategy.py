# strategy.py (전략 함수 모듈)
# =============================================
# 역할:
# 1) 기술적 분석 기반 매수 신호 전략들을 정의
# 2) 모든 전략 함수는 DataFrame과 설정(params)을 입력받아
#    매수 조건 충족 시 True, 그렇지 않으면 False 반환
# 3) STRATEGY_FUNCTIONS 딕셔너리에 함수 이름(key)과 함수(fn)를 등록
#
# 사용 예시:
#   from core.strategy import STRATEGY_FUNCTIONS
#   signals = {name: fn(df, params[name]) for name, fn in STRATEGY_FUNCTIONS.items()}
# =============================================

import pandas as pd
import numpy as np
from typing import Dict, Callable

# ======== RSI 전략 ========
# 설명: 일정 기간 RSI 값을 계산하여 매수/매도 임계값 비교
# 매수 임계값(rsi_buy_threshold) 이하일 때 True


def check_rsi(df: pd.DataFrame, params: dict) -> bool:
    # 데이터가 없거나 기간보다 짧으면 매수 신호 없음
    if df.empty or len(df) < params.get("rsi_period", 14):
        return False
    period = params.get("rsi_period", 14)
    threshold = params.get("rsi_buy_threshold", 30)
    delta = df["close"].diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.rolling(window=period).mean()
    avg_loss = loss.rolling(window=period).mean()
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    latest = rsi.iloc[-1]
    return latest <= threshold


# ======== MACD 전략 ========
# 설명: MACD 선이 시그널 선을 상향 돌파할 때 매수 신호


def check_macd(df: pd.DataFrame, params: dict) -> bool:
    # 데이터가 충분하지 않으면 매수 신호 없음
    min_len = max(params.get("slow_period", 26), params.get("signal_period", 9)) + 1
    if df.empty or len(df) < min_len:
        return False
    fast = params.get("fast_period", 12)
    slow = params.get("slow_period", 26)
    signal = params.get("signal_period", 9)
    ema_fast = df["close"].ewm(span=fast).mean()
    ema_slow = df["close"].ewm(span=slow).mean()
    macd = ema_fast - ema_slow
    sig = macd.ewm(span=signal).mean()
    # 직전값과 비교하여 골든크로스 여부 확인
    return macd.iloc[-2] < sig.iloc[-2] and macd.iloc[-1] > sig.iloc[-1]


# ======== 이동평균 골든크로스 ========
# 설명: 단기 이동평균이 장기 이동평균을 상향 돌파 시 매수


def check_ma_cross(df: pd.DataFrame, params: dict) -> bool:
    if df.empty:
        return False
    fast = params.get("fast", 5)
    slow = params.get("slow", 20)
    ma_fast = df["close"].rolling(window=fast).mean()
    ma_slow = df["close"].rolling(window=slow).mean()
    return ma_fast.iloc[-2] < ma_slow.iloc[-2] and ma_fast.iloc[-1] > ma_slow.iloc[-1]


# ======== 볼린저 밴드 하단 돌파 ========
# 설명: 종가가 하단 밴드를 하향 돌파하고 반등 조짐 시 매수


def check_bollinger(df: pd.DataFrame, params: dict) -> bool:
    if df.empty or len(df) < 20:
        return False
    mult = params.get("std_multiplier", 2.0)
    ma20 = df["close"].rolling(window=20).mean()
    std = df["close"].rolling(window=20).std()
    lower = ma20 - mult * std
    return (
        df["close"].iloc[-1] < lower.iloc[-1]
        and df["close"].iloc[-2] < df["close"].iloc[-1]
    )


# ======== 스토캐스틱 전략 ========
# 설명: %K 선이 임계값 이하일 때 D 선을 상향 돌파 시 매수


def check_stochastic(df: pd.DataFrame, params: dict) -> bool:
    if df.empty or len(df) < 14:
        return False
    k_thresh = params.get("k_threshold", 20)
    low14 = df["low"].rolling(window=14).min()
    high14 = df["high"].rolling(window=14).max()
    k = (df["close"] - low14) / (high14 - low14) * 100
    d = k.rolling(window=3).mean()
    return k.iloc[-1] <= k_thresh and k.iloc[-1] > d.iloc[-1]


# ======== 거래량 급증 전략 ========
# 설명: 평균 거래량 대비 급등 + 양봉 시 매수


def check_volume_spike(df: pd.DataFrame, params: dict) -> bool:
    if df.empty or len(df) < 10:
        return False
    mult = params.get("multiplier", 1.5)
    avg_vol = df["volume"].rolling(window=10).mean()
    return (
        df["volume"].iloc[-1] > avg_vol.iloc[-1] * mult
        and df["close"].iloc[-1] > df["open"].iloc[-1]
    )


# ======== 망치형 캔들 반전 ========
# 설명: 꼬리가 몸통의 2배 이상 길고 종가가 시가 위일 때 매수


def check_candle_reversal(df: pd.DataFrame, params: dict) -> bool:
    if df.empty:
        return False
    body = (df["close"] - df["open"]).abs()
    tail = df["open"] - df["low"]
    is_hammer = (tail > body * 2) & (df["close"] > df["open"])
    return bool(is_hammer.iloc[-1])


# ======== 추세 필터 (50MA/200MA) ========
# 설명: 50일 이동평균이 200일 이동평균 위에 있을 때만 매수 허용


def market_trend_filter(df: pd.DataFrame, params: dict) -> bool:
    if df.empty or len(df) < 200:
        return False
    ma50 = df["close"].rolling(window=50).mean()
    ma200 = df["close"].rolling(window=200).mean()
    return ma50.iloc[-1] > ma200.iloc[-1]


# ======== MACD + 거래량 결합 ========
# 설명: MACD 전략과 거래량 급증 전략이 모두 True일 때 매수


def combined_conditions(df: pd.DataFrame, params: dict) -> bool:
    return check_macd(df, params) and check_volume_spike(df, params)


# ======== 이동평균 기울기 상승 ========
# 설명: 지정 기간 이동평균이 연속 상승 중일 때 매수


def check_ma_slope_up(df: pd.DataFrame, params: dict) -> bool:
    if df.empty or len(df) < 3:
        return False
    window = params.get("ma_window", 20)
    ma = df["close"].rolling(window=window).mean()
    return ma.iloc[-1] > ma.iloc[-2] > ma.iloc[-3]


# ======== 직전 고점 돌파 ========
# 설명: 현재 종가가 이전 고점(max High)보다 높을 때 매수


def check_price_breakout(df: pd.DataFrame, params: dict) -> bool:
    if df.empty or len(df) < 2:
        return False
    prev_high = df["high"][:-1].max()
    return df["close"].iloc[-1] > prev_high


# ======== 지지선 반등 ========
# 설명: 최근 최저가 지지 구간에서 반등 조짐이 있을 때 매수


def check_support_rebound(df: pd.DataFrame, params: dict) -> bool:
    if df.empty or len(df) < 20:
        return False
    support = df["low"].rolling(window=20).min()
    return (
        df["low"].iloc[-1] <= support.iloc[-1] * 1.01
        and df["close"].iloc[-1] > df["open"].iloc[-1]
    )


# ======== 강세 엔걸핑 ========
# 설명: 이전 봉이 약세, 현재 봉이 강세이고 포개질 때 매수


def check_engulfing_bullish(df: pd.DataFrame, params: dict) -> bool:
    if df.empty or len(df) < 2:
        return False
    prev, curr = df.iloc[-2], df.iloc[-1]
    return (
        prev["close"] < prev["open"]
        and curr["close"] > curr["open"]
        and curr["close"] > prev["open"]
        and curr["open"] < prev["close"]
    )


# ======== RSI 다이버전스 ========
# 설명: 저점은 낮아지고 RSI는 상승할 때 다이버전스 매수


def check_rsi_divergence(df: pd.DataFrame, params: dict) -> bool:
    if df.empty or len(df) < 5:
        return False
    delta = df["close"].diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.rolling(window=14).mean()
    avg_loss = loss.rolling(window=14).mean()
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    return df["low"].iloc[-1] < df["low"].iloc[-3] and rsi.iloc[-1] > rsi.iloc[-3]


# ======== 갭 상승 ========
# 설명: 시가가 직전 종가 위에서 형성되고 저점이 이전 종가보다 높을 때 매수


def check_gap_up(df: pd.DataFrame, params: dict) -> bool:
    if df.empty or len(df) < 2:
        return False
    prev, curr = df.iloc[-2], df.iloc[-1]
    return curr["open"] > prev["close"] and curr["low"] > prev["close"]


# ======== MFI(자금 흐름 지수) ========
# 설명: 자금 흐름 지수가 임계값 이하일 때 매수


def check_mfi(df: pd.DataFrame, params: dict) -> bool:
    if df.empty or len(df) < params.get("period", 14):
        return False
    period = params.get("period", 14)
    threshold = params.get("threshold", 20)
    typical = (df["high"] + df["low"] + df["close"]) / 3
    money_flow = typical * df["volume"]
    direction = typical.diff().apply(lambda x: 1 if x > 0 else 0)
    pos = (money_flow * direction).rolling(window=period).sum()
    neg = (money_flow * (1 - direction)).rolling(window=period).sum().replace(0, np.nan)
    mfi = 100 - (100 / (1 + pos / neg))
    return mfi.iloc[-1] <= threshold


# ======== 피보나치 되돌림 ========
# 설명: 되돌림 레벨(38.2%, 50%, 61.8%) 근처에서 반등 시 매수


def check_fibonacci_retracement(df: pd.DataFrame, params: dict) -> bool:
    if df.empty or len(df) < params.get("lookback", 20):
        return False
    lookback = params.get("lookback", 20)
    threshold = params.get("threshold_pct", 1.0)
    high = df["high"].iloc[-lookback:].max()
    low = df["low"].iloc[-lookback:].min()
    price = df["close"].iloc[-1]
    levels = [high - (high - low) * x for x in (0.382, 0.5, 0.618)]
    return any(abs(price - lvl) / lvl * 100 < threshold for lvl in levels)


# ======== 전략 우선순위 설정 ========
# key: 함수 이름, value: 우선순위 (높을수록 우선 실행)
STRATEGY_PRIORITIES: Dict[str, int] = {
    # 우선순위: 1은 가장 우선 평가
    "check_rsi": 1,
    "check_macd": 2,
    "check_ma_cross": 3,
    "check_bollinger": 4,
    "check_stochastic": 5,
    "check_volume_spike": 6,
    "check_candle_reversal": 7,
    "check_engulfing_bullish": 8,
    "check_gap_up": 9,
    "check_price_breakout": 10,
    "check_support_rebound": 11,
    "check_ma_slope_up": 12,
    "check_mfi": 13,
    "market_trend_filter": 14,
    "combined_conditions": 15,
    "check_rsi_divergence": 16,
    "check_fibonacci_retracement": 17,
}

# ======== 전략 함수 및 우선순위 등록 ========
# 각 전략 이름에 대해 함수와 우선순위를 함께 제공
STRATEGY_FUNCTIONS: Dict[str, Dict[str, object]] = {
    name: {"func": globals()[name], "priority": STRATEGY_PRIORITIES.get(name, 0)}
    for name in STRATEGY_PRIORITIES.keys()
}

# strategy_handler.py (전략 평가 및 매수/매도 로직)
# ==============================================================
# 역할:
# 1) 매수 전략 평가: 설정된 우선순위에 따라 전략 함수 실행
# 2) 필터/트리거 로직 적용: 전략 조합 조건에 따른 최종 매수 판단
# 3) 손절/익절 평가: 보유 종목의 수익률 계산 후 매도 판단
#
# 사용 예시:
#   from core.strategy import STRATEGY_FUNCTIONS
#   results = evaluate_strategies(df, strategy_config)
#   if evaluate_buy_candidate(results, logic_config):
#       place_order()
# ==============================================================

import pandas as pd
from typing import List, Dict, Any
from core.strategy import STRATEGY_FUNCTIONS


# -------------------------------------------------------------
# 매수 전략 평가 함수
# -------------------------------------------------------------
# - 모든 전략을 우선순위 순으로 실행하여
#   첫 번째로 True를 반환한 전략이 있으면 매수 신호 발생
# - 전략 이름과 결과 리스트 반환
# -------------------------------------------------------------


def evaluate_strategies(
    df: pd.DataFrame, strategy_config: Dict[str, Dict[str, Any]]
) -> List[Dict[str, Any]]:
    """
    입력:
      - df: OHLCV DataFrame
      - strategy_config: 전략별 설정 (enabled, params 포함)
    출력:
      - [{'strategy': 이름, 'result': True/False, 'priority': 우선순위}, ...]
    """
    results = []
    # 우선순위 낮은 수부터(1부터) 높은 수 순 정렬
    for name, meta in sorted(
        STRATEGY_FUNCTIONS.items(), key=lambda x: x[1]["priority"]
    ):
        params = strategy_config.get(name, {})
        # 비활성화된 전략은 건너뜀
        if not params.get("enabled", False):
            continue
        func = meta["func"]  # 전략 함수
        prio = meta["priority"]  # 우선순위 값
        try:
            # 전략 실행, bool 반환
            ok = func(df, params)
        except Exception as e:
            # 오류 발생 시 False 처리
            print(f"⚠️ 전략 실행 오류: {name} → {e}")
            ok = False
        results.append({"strategy": name, "result": ok, "priority": prio})
        # 첫 매수 신호 발생 시 바로 중단
        if ok:
            break
    return results


# -------------------------------------------------------------
# 매수 후보 판단 함수
# -------------------------------------------------------------
# - 필터 그룹: AND 조건, 모두 True여야 통과
# - 트리거 그룹: OR/AND 모드 선택, 모드 만족 시 통과
# -------------------------------------------------------------


def evaluate_buy_candidate(
    results: List[Dict[str, Any]], logic_config: Dict[str, Any]
) -> bool:
    """
    입력:
      - results: evaluate_strategies 반환 리스트
      - logic_config:
          filter_group: 필터 전략 이름 리스트
          trigger_group: 트리거 전략 이름 리스트
          trigger_mode: 'AND' 또는 'OR'
    출력:
      - 최종 매수 여부 (True/False)
    """
    filter_group = logic_config.get("filter_group", [])
    trigger_group = logic_config.get("trigger_group", [])
    trigger_mode = logic_config.get("trigger_mode", "OR").upper()

    # 활성화된 전략 결과만 이름 추출
    passed = {r["strategy"]: r["result"] for r in results}

    # 1) 필터 그룹: 지정된 모든 전략이 True여야 통과
    for fg in filter_group:
        if not passed.get(fg, False):
            print(f"❌ 필터 그룹 불충족: {fg} 실패")
            return False

    # 2) 트리거 그룹: OR/AND 모드에 따른 평가
    trigger_results = [passed.get(tg, False) for tg in trigger_group]
    if not trigger_results:
        print("⚠️ 트리거 그룹에 활성화된 전략 없음")
        return False
    if trigger_mode == "AND":
        if not all(trigger_results):
            print(f"❌ 트리거 그룹(AND) 불충족")
            return False
    else:
        if not any(trigger_results):
            print(f"❌ 트리거 그룹(OR) 불충족")
            return False

    print("✅ 매수 조건 통과")
    return True


# -------------------------------------------------------------
# 손절/익절 조건 평가 함수
# -------------------------------------------------------------
# - 현재가, 평균 매입가로 수익률 계산
# - 수익률이 지정 임계값 이상/이하 시 True 반환
# -------------------------------------------------------------


def check_profit_loss_condition(
    current_price: float,
    avg_buy_price: float,
    stop_loss_percent: float,
    take_profit_percent: float,
) -> bool:
    """
    입력:
      - current_price: 현재가
      - avg_buy_price: 평균 매입가
      - stop_loss_percent: 손절 임계값(음수)
      - take_profit_percent: 익절 임계값(양수)
    출력:
      - 손절/익절 조건 만족 시 True
    """
    if avg_buy_price <= 0:
        print("⚠️ 평균 매입가 유효하지 않음")
        return False

    change = (current_price - avg_buy_price) / avg_buy_price * 100
    print(f"수익률: {change:.2f}% (평균 {avg_buy_price} → 현재 {current_price})")

    # 익절 조건
    if change >= take_profit_percent:
        print("💰 익절 조건 충족")
        return True
    # 손절 조건
    if change <= stop_loss_percent:
        print("🔻 손절 조건 충족")
        return True

    return False

###############################################
# ✅ [프로젝트 문서] strategy_model_a_profiles.py
#
# 📌 목적:
# - AI 기반 "추천 프로파일" 생성기
# - 시장 전체 데이터를 요약 분석
# - 전략 조합을 백테스트 후 추천
# - 사람 말처럼 이유/장점/단점 설명 포함
#
# 📌 사용 시나리오:
# - 사용자는 "추천 프로파일 생성" 버튼 클릭
# - 최근 시장 상황 기반 전략 조합 제안
# - 전략 설명과 이유, 장점, 단점 출력
#
# 📌 특징:
# - 자동매매 전략을 잘 모르는 사용자도 쉽게 사용
# - 전략 조합을 저장해 프로파일로 GUI에서 선택 가능
# - AI적 설명 생성으로 접근성 향상
#
# -------------------------------------------------
#
# ✅ 전체 처리 Flow
#
# Step 1️⃣ : 마켓 심볼 목록 수집
#    - KRW-BTC, KRW-ETH 등 모든 KRW 마켓 심볼 수집
#    - 잔고 기반이 아닌 전체 마켓 심볼
#
# Step 2️⃣ : 시장 메타데이터 분석
#    - OHLCV 데이터 기반
#    - 변동성 (일별 종가 변동 표준편차)
#    - 거래량 변화 (최근 거래량/평균 거래량)
#
# Step 3️⃣ : 전략 조합 탐색
#    - filter_group, trigger_group 후보 생성
#    - AND/OR 모드 평가
#    - 간단 수익률 시뮬레이션 (랜덤 or 실제 간이 룰)
#
# Step 4️⃣ : 가장 수익률 좋은 조합 선택
#    - 최고 백테스트 수익률 조합 선정
#
# Step 5️⃣ : 설명문 생성
#    - 시장 상황을 반영해 자연어 설명 생성
#    - "왜 이런 전략 조합인가?" 이유
#    - 장점/단점/사용팁 포함
#
# Step 6️⃣ : 프로파일 저장
#    - strategy_config.json에 신규 프로파일 추가
#    - 이름 예: "auto_recommended_23.4"
#
# -------------------------------------------------
#
# ✅ 목표
# - 코드 재사용성: 각 Step 함수로 모듈화
# - 유지보수성: 나중에 모델 개선이나 GPT 접목 쉽게
# - 사용자 친화성: 설명 친절하게
#
# -------------------------------------------------
#
# ✅ 예제 최종 프로파일 구조
# {
#   "filter_group": ["market_trend_filter", "check_volume_spike"],
#   "trigger_group": ["check_rsi", "check_macd"],
#   "trigger_mode": "OR",
#   "description": "AI가 최근 시장 데이터를 분석해 추천..."
# }
#


###############################################
# ✅ 기본 Import
###############################################
import sys, os
import io

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(BASE_DIR)
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

from core.strategy import STRATEGY_FUNCTIONS
from utils.config_loader import load_strategy_config, save_strategy_config

###############################################
# ✅ 전략별 한글 해석 딕셔너리
###############################################
STRATEGY_LABELS = {
    "check_rsi": "RSI 과매도 반전 신호",
    "check_macd": "MACD 모멘텀 진입",
    "check_ma_cross": "이동평균선 크로스 진입",
    "check_bollinger": "볼린저밴드 하단 반등 포착",
    "check_stochastic": "스토캐스틱 과매도 반등",
    "check_volume_spike": "거래량 급등 확인",
    "check_candle_reversal": "강한 반전 캔들 패턴",
    "market_trend_filter": "장기 추세 필터",
    "combined_conditions": "MACD+볼륨 동시 필터",
    "check_ma_slope_up": "이동평균선 상승 추세",
    "check_price_breakout": "최근 고점 돌파 신호",
    "check_support_rebound": "지지선 반등 확인",
    "check_engulfing_bullish": "불리쉬 인걸핑 패턴",
    "check_rsi_divergence": "RSI 다이버전스 신호",
    "check_gap_up": "갭 상승 이후 지지 확인",
    "check_mfi": "MFI 과매도 신호",
    "check_fibonacci": "피보나치 되돌림 레벨 진입",
}


###############################################
# ✅ 전략별 네이밍
###############################################
STRATEGY_NAME_KEYWORDS = {
    "market_trend_filter": "Trend",
    "check_volume_spike": "Volume",
    "check_rsi": "RSI",
    "check_macd": "MACD",
    "check_ma_cross": "MA",
    "check_bollinger": "Bollinger",
    "check_stochastic": "Stoch",
    "check_price_breakout": "Breakout",
    "check_support_rebound": "Rebound",
    "check_ma_slope_up": "Trend",
    "combined_conditions": "Combo",
    "check_gap_up": "Gap",
    # 추가 가능
}


###############################################
###############################################
# ✅ Step 1️⃣ : 마켓 심볼 목록 수집
#
# 📌 목적:
# - 전체 KRW 마켓 거래 가능 심볼 가져오기
# - 예: KRW-BTC, KRW-ETH, KRW-XRP ...
#
# 📌 특징:
# - 잔고 기반 아님 (보유/미보유 무관)
# - 매수 후보 탐색용
#
# 📌 예제 반환:
#   ["KRW-BTC", "KRW-ETH", "KRW-XRP", ...]
#
# -------------------------------------------------
def get_all_market_symbols():
    """
    ✅ 모든 KRW 마켓 심볼을 가져오는 함수
    - 빗썸 API (utils.bithumb_api)를 활용
    - KRW 마켓 필터링
    - 중복 제거
    - 오류 처리 포함
    # ✅ 함수 내 import 이유:
    # - 순환 import 방지
    # - 지연 로딩으로 의존성 최소화
    # - 필요할 때만 모듈 로드

    """
    try:
        from utils.bithumb_api import get_all_markets

        symbols = get_all_markets()
        print("[DEBUG] 최종 symbols:", symbols)
        return sorted(set(symbols))

    except Exception as e:
        print(f"❌ [Step1] 마켓 심볼 수집 실패 → {e}")
        return []


###############################################
# ✅ Step 2️⃣ : 마켓 데이터 분석
#
# 📌 목적:
# - 심볼별 OHLCV 데이터 조회
# - 전체 마켓 평균적인 시장 특성 계산
#   (최근 변동성, 거래량 변화)
#
# 📌 특징:
# - 심볼 리스트 루프 돌며 통계 수집
# - 실패 허용 (데이터 없는 심볼 스킵)
#
# 📌 예제 반환:
#   (volatility_avg, volume_change_avg)
#
# -------------------------------------------------
def analyze_market_context(symbols):
    """
    ✅ Step2 함수: 시장 컨텍스트 분석
    - 입력: 심볼 리스트
    - 출력: 평균 변동성 %, 평균 거래량 변화 %
    - 설명:
      * 각 심볼의 OHLCV 30일치 조회
      * 변동성 = 종가 수익률 표준편차
      * 거래량 변화 = 마지막 거래량 / 평균 거래량
    """
    from utils.bithumb_api import get_ohlcv

    volatilities = []
    volume_changes = []

    for ticker in symbols:
        try:
            df = get_ohlcv(ticker, interval="24h", count=30)
            if df is None or df.empty or len(df) < 5:
                continue

            returns = df["close"].pct_change().dropna()
            volatility = returns.std() * 100

            volume_change = (df["volume"].iloc[-1] / df["volume"].mean() - 1) * 100

            volatilities.append(volatility)
            volume_changes.append(volume_change)
        except Exception as e:
            print(f"⚠️ [Step2] {ticker} 분석 실패 → {e}")
            continue

    # ✅ 평균 계산 (데이터 없으면 랜덤)
    import random

    if volatilities:
        volatility_avg = sum(volatilities) / len(volatilities)
    else:
        volatility_avg = random.uniform(2, 8)

    if volume_changes:
        volume_change_avg = sum(volume_changes) / len(volume_changes)
    else:
        volume_change_avg = random.uniform(-5, 10)

    print(
        f"✅ [Step2] 시장 분석 완료 → 변동성: {volatility_avg:.2f}%, 거래량 변화: {volume_change_avg:.2f}%"
    )
    return volatility_avg, volume_change_avg


###############################################
# ✅ Step 3️⃣ : 전략 조합 평가 함수
#
# 📌 목적:
# - 필터 그룹 + 트리거 그룹 조합을 받아
# - 해당 조합의 "가상 수익률" 평가
#
# 📌 특징:
# - 현재는 예제 랜덤으로 시뮬레이트
# - 이후에는 과거데이터 기준 실제 수익률 계산으로 확장 가능
#
# 📌 예제 출력:
#   → 수익률 float
#
# -------------------------------------------------
def evaluate_strategy_combination(
    filter_group, trigger_group, trigger_mode, volatility, volume_change
):
    """
    ✅ Step3 함수: 전략 조합 평가
    - 입력:
        filter_group: 리스트
        trigger_group: 리스트
        trigger_mode: 문자열 ("AND"/"OR")
        volatility: 시장 평균 변동성
        volume_change: 시장 평균 거래량 변화
    - 출력:
        예상 수익률 (float)
    - 설명:
        * 여기선 예제 랜덤값
        * 나중엔 실제 백테스트 결과 대체
    """
    import random

    # ✅ 예제: 변동성 + 거래량 변화를 반영해 노이즈 추가
    base = random.uniform(5, 20)
    vol_bonus = (volatility - 5) * 0.5
    vol_bonus = max(-5, min(vol_bonus, 5))

    voladj = base + vol_bonus + random.uniform(-3, 3)
    voladj += volume_change / 20.0  # 거래량 변화 반영

    print(
        f"✅ [Step3] 조합 평가 → Filter:{filter_group}, Trigger:{trigger_group}, Mode:{trigger_mode} → 예상수익률:{voladj:.2f}%"
    )
    return voladj


###############################################
# ✅ Step 4️⃣ : 최적 전략 조합 탐색
#
# 📌 목적:
# - 모든 전략 조합을 생성해
# - 각각 evaluate_strategy_combination으로 평가
# - 가장 높은 예상 수익률의 조합을 선정
#
# 📌 특징:
# - 현재는 필터 1~2개 / 트리거 2~3개 제한
# - 이후에는 전략 수/제약조건을 더 세밀하게 조정 가능
#
# 📌 예제 출력:
#   best_filter, best_trigger, best_mode, best_profit
#
# -------------------------------------------------
def find_best_strategy_combination(all_strategies, volatility, volume_change):
    """
    ✅ Step4 함수: 모든 전략 조합 탐색
    - 입력:
        all_strategies: 전체 전략 키 리스트
        volatility, volume_change: 시장 상황
    - 출력:
        best_filter (list)
        best_trigger (list)
        best_mode (str)
        best_profit (float)
    """
    import itertools

    best_profit = -999
    best_filter = []
    best_trigger = []
    best_mode = "OR"

    # ✅ 예제: 필터 1~2개 / 트리거 2~3개 조합
    for f_count in [1, 2]:
        for t_count in [2, 3]:
            filter_combos = itertools.combinations(all_strategies, f_count)
            trigger_combos = itertools.combinations(all_strategies, t_count)

            for filter_group in filter_combos:
                for trigger_group in trigger_combos:
                    for mode in ["AND", "OR"]:
                        score = evaluate_strategy_combination(
                            list(filter_group),
                            list(trigger_group),
                            mode,
                            volatility,
                            volume_change,
                        )
                        if score > best_profit:
                            best_profit = score
                            best_filter = list(filter_group)
                            best_trigger = list(trigger_group)
                            best_mode = mode

    print(
        f"\n✅ [Step4] 최종 선정 → 수익률:{best_profit:.2f}% | Filter:{best_filter} | Trigger:{best_trigger} | Mode:{best_mode}"
    )
    return best_filter, best_trigger, best_mode, best_profit


###############################################
# ✅ Step 5️⃣ : 자동 생성 설명문 생성
#
# 📌 목적:
# - 필터/트리거 그룹을 사람이 이해할 수 있게 자연어로 설명
# - 시장 상황(변동성/볼륨)을 반영
# - 전략별 라벨 딕셔너리(STRATEGY_LABELS) 사용
#
# 📌 특징:
# - 한글 문장 중심
# - 전략 목록을 해석해 이유/장점/단점/사용팁 생성
#
# 📌 예제 출력:
#   설명 문자열 (str)
#
# -------------------------------------------------
def generate_profile_description(
    filter_group,
    trigger_group,
    trigger_mode,
    volatility,
    volume_change,
    expected_profit,
):
    """
    ✅ Step5 함수: 추천 프로파일 설명문 생성
    - 입력:
        filter_group, trigger_group, trigger_mode
        volatility, volume_change
        expected_profit
    - 출력:
        description (str)
    """
    # ✅ 전략 라벨 해석
    filter_desc = ", ".join(STRATEGY_LABELS.get(s, s) for s in filter_group)
    trigger_desc = ", ".join(STRATEGY_LABELS.get(s, s) for s in trigger_group)

    # ✅ 시장 상황 기반 텍스트
    volatility_comment = (
        "최근 시장이 변동성이 높아져 단타 기회가 늘어났습니다."
        if volatility > 5
        else "최근 시장이 비교적 안정적입니다."
    )
    volume_comment = (
        "거래량이 증가하며 매수세가 유입되고 있습니다."
        if volume_change > 0
        else "거래량이 다소 감소세를 보입니다."
    )

    # ✅ 최종 설명 생성
    description = (
        f"✅ AI 자동 생성 추천 프로파일입니다.\n"
        f"예상 수익률: {expected_profit:.1f}%\n\n"
        f"✔️ 최근 시장 분석:\n"
        f"- 변동성: {volatility:.1f}% ({volatility_comment})\n"
        f"- 거래량 변화: {volume_change:.1f}% ({volume_comment})\n\n"
        f"✔️ 필터 그룹 전략:\n"
        f"{filter_desc}\n"
        f"- 오신호를 제거하고 시장의 주요 추세를 확인하도록 설계했습니다.\n\n"
        f"✔️ 트리거 그룹 전략:\n"
        f"{trigger_desc}\n"
        f"- 진입 타이밍을 세밀하게 포착하기 위해 설계했습니다.\n\n"
        f"✔️ 추천 이유:\n"
        f"- 최근 시장 상황을 반영해 최적화된 전략 조합입니다.\n"
        f"- 변동성 및 거래량 변화 패턴을 분석한 결과 유망한 진입 신호를 제공.\n\n"
        f"✔️ 장점:\n"
        f"- 시장 맞춤형 전략으로 오버트레이딩 방지.\n"
        f"- 다양한 신호를 결합해 신뢰도를 높였습니다.\n\n"
        f"✔️ 단점:\n"
        f"- 시장 상황이 변하면 오버피팅 우려.\n"
        f"- 데이터 품질과 지연에 따른 예측 오차 가능성.\n\n"
        f"✔️ 사용 팁:\n"
        f"- 단기 변동성 장세에서 적극 활용 권장.\n"
        f"- 전략 파라미터를 시장 상황에 따라 조정하세요.\n"
    )

    return description


###############################################
# ✅ Step 6️⃣ : 추천 프로파일 저장
#
# 📌 목적:
# - 추천된 전략 조합과 설명문을 strategy_config.json에 저장
#
# 📌 특징:
# - 프로파일 이름 자동 생성 (예상 수익률 기반)
# - 필터/트리거/모드/설명 모두 포함
#
# 📌 예제 출력:
#   저장 완료 메시지
#
# -------------------------------------------------
def save_recommended_profile_to_config(
    filter_group, trigger_group, trigger_mode, expected_profit, description
):
    """
    ✅ Step6 함수: 추천 프로파일을 config.json에 저장
    - 입력:
        filter_group, trigger_group, trigger_mode
        expected_profit, description
    - 처리:
        strategy_config.json의 profiles 섹션에 추가
    """
    config = load_strategy_config()
    profiles = config.profiles  # dict of existing profiles

    # ✅ 사람이 읽을만한 이름 생성
    base_name = generate_readable_profile_name(
        filter_group, trigger_group, expected_profit
    )
    profile_name = generate_unique_profile_name(base_name, profiles)

    new_profile = {
        "filter_group": filter_group,
        "trigger_group": trigger_group,
        "trigger_mode": trigger_mode,
        "description": description,
    }

    profiles[profile_name] = new_profile
    config.profiles = profiles
    save_strategy_config(cfg=config)

    print(f"✅ 새로운 추천 프로파일 생성 완료 → {profile_name}")

    return profile_name


###############################################
# ✅ 유니크 프로파일 이름 중복 방지
###############################################
def generate_unique_profile_name(base_name, existing_profiles):
    """
    ✅ 기존 프로파일 목록과 비교해
    중복을 피해 유니크한 이름을 만들어 반환
    예:
      base_name → 'auto_recommended_24.4'
      기존: {'auto_recommended_24.4', 'auto_recommended_24.4_1'}
      반환: 'auto_recommended_24.4_2'
    """
    if base_name not in existing_profiles:
        return base_name

    counter = 1
    while f"{base_name}_{counter}" in existing_profiles:
        counter += 1
    return f"{base_name}_{counter}"


###############################################
# ✅ 유니크 프로파일 이름 생성 함수
###############################################
def generate_readable_profile_name(filter_group, trigger_group, expected_profit):
    """
    ✅ 필터/트리거 전략명을 기반으로
    사람이 읽을만한 이름 생성
    예:
      Trend_Volume_25.3
    """
    parts = []

    # 필터
    for key in filter_group:
        parts.append(STRATEGY_NAME_KEYWORDS.get(key, "Filter"))

    # 트리거
    for key in trigger_group:
        parts.append(STRATEGY_NAME_KEYWORDS.get(key, "Trigger"))

    # 중복 제거
    parts = list(dict.fromkeys(parts))

    # 너무 길면 앞에서 2~3개만
    if len(parts) > 3:
        parts = parts[:3]

    # 예상 수익률 붙이기
    profit_str = f"{expected_profit:.1f}"

    return "_".join(parts + [profit_str])


###############################################
# ✅ 모든 전략 키 로드
###############################################
def load_all_strategy_keys():
    return list(STRATEGY_FUNCTIONS.keys())


###############################################
# ✅ Step 7️⃣ : 메인 함수 - 추천 프로파일 생성기
#
# 📌 목적:
# - 전체 Step1~Step6 함수를 한 번에 실행
# - CLI/스크립트 실행 시 동작
#
# 📌 특징:
# - 자동으로 시장 데이터 분석
# - 전략 조합 추천
# - 설명문 생성
# - config.json에 저장
#
# -------------------------------------------------
def generate_recommended_profile():
    """
    ✅ Step7: 메인 실행 함수
    - 시장 컨텍스트 분석
    - 전략 후보 탐색
    - 베스트 조합 선택
    - 설명문 생성
    - 저장
    """

    print("✅ [추천 프로파일 생성] 시작")

    ###############################################
    # 1️⃣ 심볼 먼저 수집
    ###############################################
    symbols = get_all_market_symbols()

    if not symbols:
        # Bithumb API IP 제한 등으로 빈 리스트가 넘어오면,
        # 최소한 하나의 심볼을 강제로 추가해서 스크립스가 죽지 않게 합니다.
        print("⚠️ 심볼 수집 실패, 기본 심볼(KRW-BTC)로 대체")

    ###############################################
    # 1️⃣  시장 데이터 분석
    ###############################################
    volatility, volume_change = analyze_market_context(symbols)
    if volatility is None or volume_change is None:
        raise ValueError("시장 데이터 분석 실패")
    print(f"✅ 시장 변동성: {volatility:.2f}% | 거래량 변화: {volume_change:.2f}%")

    ###############################################
    # 2️⃣ 전략 후보 로드
    ###############################################
    all_strategies = load_all_strategy_keys()
    print(f"✅ 전체 전략 수: {len(all_strategies)}")

    ###############################################
    # 3️⃣ 추천 조합 탐색
    ###############################################
    best_filter, best_trigger, best_mode, best_profit = find_best_strategy_combination(
        all_strategies, volatility, volume_change
    )
    print(f"✅ 추천 조합 → 필터={best_filter}, 트리거={best_trigger}, 모드={best_mode}")

    ###############################################
    # 4️⃣ 설명문 생성
    ###############################################
    description = generate_profile_description(
        best_filter, best_trigger, best_mode, volatility, volume_change, best_profit
    )
    print(f"✅ 설명문 생성 완료")

    ###############################################
    # 5️⃣ 저장
    ###############################################
    profile_name = save_recommended_profile_to_config(
        best_filter, best_trigger, best_mode, best_profit, description
    )

    return profile_name


###############################################
# ✅ 스크립트 직접 실행
###############################################
if __name__ == "__main__":
    try:
        generated_name = generate_recommended_profile()
        if generated_name:
            print(f"PROFILE_NAME:{generated_name}")
            sys.exit(0)
        else:
            print("ERROR:No profile generated")
            sys.exit(1)
    except Exception as e:
        print(f"ERROR:{e}")
        sys.exit(1)

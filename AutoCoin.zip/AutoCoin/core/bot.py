###############################################
# ✅ 📌 [BOT.PY 설계 문서]
#
# ✅ 목적:
# - 코인 자동매매 메인 루프
# - 전략 A,B 모델을 모두 통합
# - 자동매매 봇으로 24시간 운용 가능
#
# ✅ 주요 기능:
# 1️⃣ 설정 로딩
# 2️⃣ 잔고 조회
# 3️⃣ 매도 평가 및 실행
# 4️⃣ 매수 후보 선정
#    - A: 추천 프로파일 사용 (자동 프로파일 재추천 포함)
#    - B: 단계적 필터링
# 5️⃣ 매수 실행
# 6️⃣ 쿨다운/플래그 관리
#
# ✅ 루프:
# - 매번 설정/전략 새로 로딩
# - loop_interval_seconds 간격 반복
###############################################


import sys
import json
import time
import subprocess
import logging
from pathlib import Path

# ─────────────────────────────────────────────
# 📂 경로 세팅
# ─────────────────────────────────────────────
BASE_DIR = Path(__file__).resolve().parents[1]
sys.path.append(str(BASE_DIR))

# ─────────────────────────────────────────────
# 🔧 유틸 / API / 로거
# ─────────────────────────────────────────────
from utils.bithumb_api import (
    get_all_balances,
    get_current_price,
    get_min_order_amounts,
)
from utils.telegram import send_telegram_message
from utils.logger import setup_logger

# 🏷️ 거래 실행 & 상태
from trading.trade_executor import execute_order
from trading.state_manager import (
    clear_expired_cooldowns,
    set_cooldown,
    set_trade_flag,
)

# 🧠 전략 헬퍼
from core.strategy_handler import check_profit_loss_condition

# 🅰️ / 🅱️  모델
from core.strategy_model_a_profiles import generate_recommended_profile
from core.strategy_model_b_filtering import (
    run_stepwise_filter_buy,
)  # returns candidate count

# ─────────────────────────────────────────────
# 📄 CONFIG 경로
# ─────────────────────────────────────────────
from utils.config_loader import load_config, load_strategy_config

from core.strategy_model_b_filtering import _calculate_allocation


# ─────────────────────────────────────────────
# ✅ [1️⃣] 잔고 조회 함수
# ─────────────────────────────────────────────
def fetch_balances(logger: logging.Logger):
    """
    ✅ 빗썸 전체 잔고 조회
    - KRW, 코인별 수량 및 평단가 반환
    """
    try:
        balances = get_all_balances()
        logger.info(f"잔고 조회: {balances}")
    except Exception as e:
        logger.error(f"잔고 조회 실패: {e}")
        send_telegram_message(f"🚨 API 연결 실패 (잔고 조회): {e}")
        sys.exit(1)

    krw_balance = balances.get("KRW", {}).get("balance", 0.0)
    coin_holdings = {
        sym: info
        for sym, info in balances.items()
        if sym not in ["KRW", "ETH2", "P"] and info.get("balance", 0) > 0
    }
    return krw_balance, coin_holdings


# ─────────────────────────────────────────────
# ✅ [2️⃣] 매도 평가 및 실행
# ─────────────────────────────────────────────


def evaluate_and_execute_sell(
    coin_holdings,
    stop_loss,
    take_profit,
    sell_ratio,
    min_conditions,
    logger: logging.Logger,
    mode: str,
):
    """
    ✅ 보유 자산 매도 평가 및 실행
    """
    if not coin_holdings:
        logger.warning("매도 평가 스킵 → 보유 코인 없음")
        return
    if isinstance(min_conditions, list):
        min_conditions = {ticker: {"min_total": 5000} for ticker in coin_holdings}

    executed = {}  # 여기에 체결된 종목별 정보 담기

    for sym, info in coin_holdings.items():
        ticker = f"KRW-{sym}"
        balance = info.get("balance", 0)
        avg_price = info.get("avg_buy_price", 0)
        if balance <= 0 or avg_price <= 0:
            continue

        try:
            current = get_current_price(ticker)
        except Exception as e:
            logger.error(f"현재가 조회 실패 ({ticker}): {e}")
            send_telegram_message(f"🚨 API 연결 실패 (현재가 조회 {ticker}): {e}")
            sys.exit(1)
        if not check_profit_loss_condition(current, avg_price, stop_loss, take_profit):
            continue

        amount = round(balance * sell_ratio, 8)
        min_total = min_conditions.get(ticker, {}).get("min_total", 5000)
        logger.info(
            f"매도 평가: {ticker} balance={balance}, amount={amount}, price={current}"
        )

        # 주문 실행
        success = execute_order(ticker, "ask", amount, current, min_total, logger, mode)
        if not success:
            send_telegram_message(f"🚨 매도 주문 실패: {ticker}")
        else:
            executed[sym] = {
                "order_id": getattr(success, "order_id", None),
                "price": current,
                "quantity": amount,
            }
            send_telegram_message(f"🚨 매도 주문 성공: {ticker}")

    # for 루프가 끝난 뒤, collected dict 를 반환합니다.
    return executed


# ─────────────────────────────────────────────
# ✅ [3️⃣] 쿨다운/플래그 관리
# ─────────────────────────────────────────────
def manage_cooldowns(logger: logging.Logger):
    clear_expired_cooldowns()
    logger.info("쿨다운 만료 관리 완료")


# ─────────────────────────────────────────────
# ✅ [4️⃣] 메인 루프
# ─────────────────────────────────────────────
def main_loop():
    # 1) 설정 로드 + 로거 세팅
    main_cfg = load_config()
    log_base = str(main_cfg.log_path)
    logger = setup_logger(log_base)
    logger.info("자동매매 봇 시작")
    send_telegram_message("🤖 자동매매 봇 시작")

    zero_hit = 0

    while True:
        logger.info("===== 자동매매 루프 시작 =====")

        # Pydantic V2: 속성 직접 접근
        mode = main_cfg.mode
        strat_cfg_path = main_cfg.strategy_config_path
        log_path = main_cfg.log_path
        # 메타 파라미터

        strat_cfg = load_strategy_config(path=strat_cfg_path)  # StrategyConfig 객체
        meta = strat_cfg.meta
        mode = main_cfg.mode

        zero_limit = meta["zero_hit_limit"]
        stop_loss = strat_cfg.meta.get("stop_loss_percent", -5.0)
        take_profit = strat_cfg.meta.get("take_profit_percent", 5.0)
        buy_ratio = strat_cfg.meta.get("buy_ratio_percent", 50) / 100
        sell_ratio = strat_cfg.meta.get("sell_ratio_percent", 50) / 100
        interval = strat_cfg.meta.get("loop_interval_seconds", 60)

        # 1) 잔고 조회 & 매도
        krw_bal, holds = fetch_balances(logger)
        tickers = [f"KRW-{s}" for s in holds]
        min_conds = get_min_order_amounts(tickers)
        evaluate_and_execute_sell(
            holds, stop_loss, take_profit, sell_ratio, min_conds, logger, mode
        )

        # 2) 매수 후보 선정
        profiles = strat_cfg.profiles
        selected = strat_cfg.selected_profile

        if selected not in profiles:
            logger.warning("프로파일 없음 → 매수 스킵")
            cand_cnt = 0
        else:
            logger.info(f"프로파일 적용 → {selected}")
            try:
                cand_cnt = (
                    run_stepwise_filter_buy(
                        strat_cfg, krw_bal, buy_ratio, log_path, mode
                    )
                    or 0
                )
            except Exception as e:
                logger.error(f"매수 후보 선정 실패: {e}")
                send_telegram_message(f"🚨 API 연결 실패 (매수 후보): {e}")
                sys.exit(1)

        # 3) 연속 실패 카운트
        if cand_cnt == 0:
            zero_hit += 1
            logger.warning(f"매수 후보 없음 → zero_hit={zero_hit}/{zero_limit}")
            if zero_hit >= zero_limit:
                logger.info("연속 실패 한계치 도달 → 자동추천 실행")
                subprocess.run(
                    [
                        sys.executable,
                        str(BASE_DIR / "core" / "strategy_model_a_profiles.py"),
                    ],
                    check=True,
                )
                send_telegram_message("🆕 추천 프로파일 재생성 완료")
                zero_hit = 0
        else:
            zero_hit = 0

        # 4) 쿨다운 관리
        manage_cooldowns(logger)

        # 5) 다음 루프 대기
        logger.info(f"루프 대기: {interval}s")
        time.sleep(interval)


if __name__ == "__main__":
    main_loop()

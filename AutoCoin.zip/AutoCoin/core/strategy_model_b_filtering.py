# strategy_model_b_filtering.py ###################
# ✅ 📌 전략 모델 B : 단계적 필터링 후보 선정
#
# 📌 목적:
# - 선택된 프로파일의 filter_group + trigger_group을
#   시장의 모든 심볼에 적용해 매수 후보 선정
# - 후보가 너무 많으면 단계적으로 전략 추가 적용해 좁힘
#
# 📌 사용 시나리오:
# - 사용자가 GUI에서 프로파일 선택
# - 매수 루프에서 B 모델 호출 → 후보 심볼 반환
#
# -------------------------------------------------
#
# ✅ 주요 Step
#
# Step 1️⃣ : 마켓 심볼 전체 불러오기
# - KRW-BTC, KRW-ETH 등 모든 KRW 마켓
#
# Step 2️⃣ : OHLCV 데이터 수집
# - 각 심볼의 최근 데이터
#
# Step 3️⃣ : 프로파일 전략 평가
# - filter_group : AND 조건
# - trigger_group : AND / OR 조건
#
# Step 4️⃣ : 단계적 필터링
# - 후보가 너무 많으면 → 추가 전략 적용
# - 후보가 너무 적으면 → 전략 조합 완화
#
# Step 5️⃣ : 최종 후보 반환
# - 매수 대상 심볼 리스트
#
# -------------------------------------------------
#
# ✅ 특징:
# - 자동매매 루프에서 반복 적용 가능
# - A가 생성한 프로파일을 그대로 사용
# - 사용자 입력 필요 없이 후보를 자동 추천
#
# ✅ 예제 출력:
#   ["KRW-BTC", "KRW-ETH"]
#
###############################################

from utils.bithumb_api import get_all_markets
from utils.bithumb_api import get_ohlcv
from core.strategy import STRATEGY_FUNCTIONS
from utils.bithumb_api import get_current_price, get_min_order_amounts
from trading.trade_executor import execute_order
from trading.state_manager import (
    is_traded_today,
    is_on_cooldown,
    set_trade_flag,
    set_cooldown,
)
from utils.telegram import send_telegram_message


###############################################
# ✅ Step 1️⃣ : 마켓 심볼 전체 불러오기
#
# 📌 목적:
# - 빗썸 KRW 마켓 전체 심볼 가져오기
# - 예) KRW-BTC, KRW-ETH ...
#
# 📌 특징:
# - 잔고 여부와 무관
# - 매수 후보 풀(전체 심볼) 구성
#
# 📌 출력 예시:
#   ["KRW-BTC", "KRW-ETH", "KRW-XRP", ...]
#
###############################################
def get_all_market_symbols_for_filter():
    """
    ✅ Step1 함수
    - 빗썸 API 호출
    - KRW 마켓 심볼 필터
    - 중복 제거 및 정렬
    """
    try:

        markets = get_all_markets()
        symbols = [m["market"] for m in markets if m["market"].startswith("KRW-")]
        symbols = sorted(set(symbols))
        print(f"✅ [Step1] 전체 심볼 수집 완료 → {len(symbols)}종목")
        return symbols
    except Exception as e:
        print(f"❌ [Step1] 심볼 수집 실패 → {e}")
        return []


###############################################
# ✅ Step 2️⃣ : 전략 평가용 OHLCV 데이터 수집
#
# 📌 목적:
# - 필터링 단계에서 사용할 최근 가격 데이터 확보
# - 후보 심볼별로 OHLCV 데이터 딕셔너리 생성
#
# 📌 특징:
# - 모든 심볼 반복 조회
# - 실패 시 스킵
#
# 📌 출력 예시:
#   {
#     "KRW-BTC": DataFrame,
#     "KRW-ETH": DataFrame,
#     ...
#   }
#
###############################################
def fetch_ohlcv_for_symbols(symbols, interval="24h", count=100):
    """
    ✅ Step2 함수
    - 입력:
        symbols: 심볼 리스트
        interval: 캔들 주기
        count: 데이터 개수
    - 출력:
        {symbol: DataFrame} 딕셔너리
    - 설명:
        * 실패 심볼은 제외
    """

    result = {}

    for ticker in symbols:
        try:
            df = get_ohlcv(ticker, interval=interval, count=count)
            if df is None or df.empty or len(df) < 10:
                continue
            result[ticker] = df
        except Exception as e:
            print(f"⚠️ [Step2] {ticker} OHLCV 수집 실패 → {e}")

    print(f"✅ [Step2] OHLCV 수집 완료 → {len(result)}종목")
    return result


###############################################
# ✅ Step 3️⃣ : 전략별 개별 평가
#
# 📌 목적:
# - 심볼별 OHLCV 데이터에 전략 함수 적용
# - 개별 전략 평가 결과를 구조화
#
# 📌 특징:
# - 전략 활성화 여부(config) 반영
# - 전략 함수 → (buy/hold, 이유) 반환
#
# 📌 출력 예시:
#   {
#     "KRW-BTC": [
#         {"strategy": "check_rsi", "action": "buy", "reason": "RSI=29.1"},
#         ...
#     ],
#     ...
#   }
#
###############################################
def evaluate_strategies_for_symbols(ohlcv_dict, strategy_config):
    """
    ✅ Step3 함수
    - 입력:
        ohlcv_dict: {symbol: DataFrame}
        strategy_config: 전략 파라미터 및 활성화 여부
    - 출력:
        {symbol: [전략평가결과...]}
    - 설명:
        * 전략별 함수 호출
        * buy/hold 결과 저장
    """

    results = {}

    for symbol, df in ohlcv_dict.items():
        symbol_results = []

        for strategy_name, params in strategy_config.items():
            if not params.get("enabled"):
                continue

            func = STRATEGY_FUNCTIONS.get(strategy_name)
            if not func:
                print(f"⚠️ 전략 함수 없음 → {strategy_name}")
                continue

            try:
                action, reason = func(df, params)
            except Exception as e:
                action, reason = "error", f"Exception: {str(e)}"

            symbol_results.append(
                {"strategy": strategy_name, "action": action, "reason": reason}
            )

        results[symbol] = symbol_results

    print(f"✅ [Step3] 전략 평가 완료 → {len(results)}종목 처리")
    return results


###############################################
# ✅ Step 4️⃣ : 단계적 필터링 적용
#
# 📌 목적:
# - 전략 평가 결과를 순차적으로 필터링
# - 전략 조합을 단계적으로 추가 → 후보 수 감소
#
# 📌 특징:
# - 우선순위 전략 리스트 적용
# - 하나씩 필터를 추가하며 후보 수 확인
#
# 📌 출력 예시:
#   최종 매수 후보 리스트
#
###############################################
def stepwise_filter_candidates(
    strategy_results, priority_order, min_count=1, max_count=5
):
    """
    ✅ Step4 함수
    - 입력:
        strategy_results: {symbol: [전략별 평가]}
        priority_order: 적용할 전략 우선순위 리스트
        min_count: 후보가 최소 몇 개 나올때까지
        max_count: 후보가 최대 몇 개 나올때까지
    - 출력:
        최종 매수 후보 리스트
    - 설명:
        * 초기 후보 = 전체 심볼
        * 각 전략을 순차적으로 필터로 적용
        * 후보 수가 [min_count, max_count]에 들어오면 멈춤
    """
    candidates = list(strategy_results.keys())
    print(f"✅ [Step4] 초기 후보 종목 수: {len(candidates)}")

    for strat in priority_order:
        new_candidates = []

        for sym in candidates:
            results = strategy_results[sym]
            for r in results:
                if r["strategy"] == strat and r["action"].lower() == "buy":
                    new_candidates.append(sym)
                    break

        candidates = new_candidates
        print(f"✔️ 전략 {strat} 적용 후 후보 수: {len(candidates)}")

        if len(candidates) <= max_count and len(candidates) >= min_count:
            print(f"✅ [Step4] 필터링 완료 → {len(candidates)}개 후보 선정")
            return candidates

    print(f"⚠️ [Step4] 필터링 최종 결과 → {len(candidates)}개")
    return candidates


###############################################
# ✅ Step 5️⃣ : 후보 예산 분배 계산
#
# 📌 목적:
# - 매수할 최종 후보 리스트가 정해진 뒤
# - 전체 잔고 대비 예산 분배 금액 계산
#
# 📌 특징:
# - 유저의 KRW 잔고, buy_ratio 퍼센트 반영
# - 후보 수에 맞춰 1/N 분할
# - 최소 주문금액 이하인 경우 스킵
#
# 📌 예제 출력:
#   { "KRW-BTC": 20000, "KRW-ETH": 20000, ... }
#
###############################################
def allocate_budget_per_candidate(
    candidates, krw_balance, buy_ratio, min_order_total=5000
):
    """
    ✅ Step5 함수
    - 입력:
        candidates: 매수 후보 심볼 리스트
        krw_balance: 현재 KRW 잔고
        buy_ratio: 사용 비율 (0.5 = 50%)
        min_order_total: 최소 주문금액
    - 출력:
        {symbol: 예산 금액} 딕셔너리
    - 설명:
        * 전체 예산 = KRW 잔고 * buy_ratio
        * 후보 수로 1/N 분할
        * 최소 주문금액 이상만 리턴
    """
    if not candidates:
        print("⚠️ [Step5] 후보 없음 → 예산 분배 스킵")
        return {}

    usable_budget = krw_balance * buy_ratio
    per_coin_budget = usable_budget / len(candidates)

    allocation = {}
    for sym in candidates:
        if per_coin_budget >= min_order_total:
            allocation[sym] = per_coin_budget
        else:
            print(f"⚠️ [Step5] {sym} → 예산 {per_coin_budget:.0f} KRW (최소금액 미달)")

    print(f"✅ [Step5] 최종 예산 분배 → {allocation}")
    return allocation


def _calculate_allocation(portfolio: dict, max_positions: int) -> dict:
    """
    전체 KRW 잔고를 max_positions 개수로 균등 분배한 예산 딕셔너리 반환
    """
    total_krw = portfolio.get("KRW", 0)
    if max_positions <= 0:
        return {}
    per_pos = total_krw / max_positions
    return {sym: per_pos for sym in portfolio if sym != "KRW"}


###############################################
# ✅ Step 6️⃣ : 매수 주문 실행
#
# 📌 목적:
# - Step5에서 계산된 예산 배분을 기반으로
# - 각 심볼별 매수 주문 실행
#
# 📌 특징:
# - 현재가 조회
# - 매수 수량 계산
# - 최소 주문금액 확인
# - 주문 실행 함수 호출
#
# 📌 예제 출력:
#   매수 주문 로그
#
###############################################
def execute_buy_orders(allocation, mode, log_path):
    """
    ✅ Step6 함수
    - 입력:
        allocation: {symbol: budget} 딕셔너리
        mode: 'real' or 'paper'
        log_path: 로그 저장 경로
    - 출력:
        없음 (실행 로그 출력)
    - 설명:
        * 심볼별 현재가 조회
        * 주문 수량 계산
        * 최소 주문금액 확인
        * 주문 실행
    """
    try:
        print("▶ alloc:", allocation)  # 혹은 self.txt_fill.insert로 화면에 찍어 보기

        if mode == "paper":
            _is_traded_today = lambda *args, **kwargs: False
            _is_on_cooldown = lambda *args, **kwargs: False
        else:
            from trading.state_manager import is_traded_today as _is_traded_today
            from trading.state_manager import is_on_cooldown as _is_on_cooldown

        if not allocation:
            print("⚠️ [Step6] 분배 예산 없음 → 매수 스킵")
            return

        executed = {}  # 리턴값 담을 dic
        symbols = list(allocation.keys())
        min_conditions = get_min_order_amounts(symbols)

        for ticker in symbols:
            # ── 1) 오늘 이미 거래했는지 체크
            if _is_traded_today(ticker):
                print(f"⚠️ [Step6] {ticker} → 오늘 이미 거래됨, 스킵")
                continue
            # ── 2) 쿨다운 중인지 체크
            if _is_on_cooldown(ticker):
                print(f"⚠️ [Step6] {ticker} → 쿨다운 중, 스킵")
                continue
            budget = allocation[ticker]
            min_total = min_conditions.get(ticker, {}).get("min_total", 5000)

            price = get_current_price(ticker)
            if not price:
                print(f"⚠️ [Step6] 현재가 조회 실패 → {ticker}")
                continue

            amount = round(budget / price, 8)
            order_value = amount * price

            if order_value < min_total:
                print(f"⚠️ [Step6] {ticker} 주문금액 미달 → {order_value:.0f} KRW")
                continue

            print("\n====================")
            print(f"✅ 매수 평가: {ticker}")
            print(f"   → 예산: {budget:.0f} KRW")
            print(f"   → 현재가: {price}")
            print(f"   → 매수 수량: {amount:.8f}")

            success = execute_order(
                ticker=ticker,
                side="bid",
                amount=amount,
                price=price,
                min_total=min_total,
                log_path=log_path,
                mode=mode,
            )

            if success:
                executed[ticker] = {
                    "order_id": getattr(success, "order_id", None),
                    "price": price,
                    "quantity": amount,
                }
                send_telegram_message(
                    f"✅ [매수 체결]\n"
                    f"{ticker} {success.amount}개 @ {success.price:,}원"
                )
                # ── 3) 성공 시 일일 플래그 설정 & 쿨다운 설정
                set_trade_flag(ticker)
                set_cooldown(ticker, "buy")

        return executed
    except Exception as e:
        print("🔥 execute_buy_orders error:", e)
        raise


###############################################
# ✅ Step 7️⃣ : 메인 함수 - 단계적 필터링 매수 시퀀스
#
# 📌 목적:
# - Step1~Step6을 순서대로 실행
# - 종목 선정부터 매수까지 자동 처리
#
# 📌 특징:
# - 시장 데이터 기반 전략 필터링
# - 단계별 후보 줄이기
# - 예산 분배 후 매수 실행
#
# 📌 예제 사용:
#   run_stepwise_filter_buy(mode="real")
#
###############################################
def run_stepwise_filter_buy(strategy_config, krw_balance, buy_ratio, log_path, mode):
    """
    ✅ Step7 메인 실행 함수
    - 입력:
        strategy_config: strategy_config.json 딕셔너리
        krw_balance: 현재 KRW 잔고
        buy_ratio: 사용 비율 (ex 0.5)
        log_path: 로그 파일 경로
        mode: 'real' or 'paper'
    - 처리:
        Step1~Step6 순차 호출
    - 출력:
        없음 (로그 출력)
    """
    print("\n==============================")
    print("✅ [Stepwise 필터 모델] 단계적 매수 프로세스 시작")

    ###############################################
    # 1️⃣ 시장 전체 심볼 수집
    ###############################################
    symbols = get_all_market_symbols_for_filter()
    if not symbols:
        print("❌ 심볼 수집 실패 → 종료")
        return

    ###############################################
    # 2️⃣ 전략 필터 평가
    ###############################################
    filtered = fetch_ohlcv_for_symbols(symbols, strategy_config)
    if not filtered:
        print("⚠️ [Step7] 필터 단계 통과 심볼 없음 → 종료")
        return

    ###############################################
    # 3️⃣ 트리거 평가
    ###############################################
    final_candidates = evaluate_strategies_for_symbols(filtered, strategy_config)
    if not final_candidates:
        print("⚠️ [Step7] 트리거 단계 통과 심볼 없음 → 종료")
        return

    ###############################################
    # 4️⃣ 예산 분배
    ###############################################
    allocation = allocate_budget_per_candidate(final_candidates, krw_balance, buy_ratio)
    if not allocation:
        print("⚠️ [Step7] 매수 예산 분배 실패 → 종료")
        return

    ###############################################
    # 5️⃣ 매수 실행
    ###############################################
    execute_buy_orders(allocation, mode, log_path)

    print("✅ [Stepwise 필터 모델] 단계적 매수 프로세스 완료")
    return len(final_candidates)

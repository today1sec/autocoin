###############################################
# ✅ 📌 전략 프로파일 선택 + 편집모드 + 우선순위 편집 GUI 설계
#
# ✅ 목적
# - strategy_config.json의 profiles 리스트에서 선택
# - 선택된 프로파일의 filter_group, trigger_group 전략만 체크
# - 전략별 ON/OFF 설정 편집 가능
# - 전략 우선순위 편집 가능 (Drag&Drop)
# - 모든 전략 체크박스는 읽기전용 모드와 편집모드 전환 가능
# - 프로파일 생성/삭제 지원
#
# ✅ 주요 기능
# 1️⃣ 프로파일 선택 드롭다운
#    - 저장된 profiles 리스트 선택
#    - 선택 시 전략 조합 자동 반영
#
# 2️⃣ 편집모드 ON/OFF 버튼
#    - ON → 체크박스 활성화 (수정 가능)
#    - OFF → 읽기전용(disabled)
#
# 3️⃣ 전략별 설정
#    - 체크박스 (활성화 여부)
#    - 파라미터 입력
#    - 전략 설명 라벨 표시
#
# 4️⃣ 전략 우선순위 편집
#    - Drag&Drop 리스트
#    - 순서 변경
#    - "순서 저장" 버튼 → priority_order 저장
#
# 5️⃣ 프로파일 추가/삭제 버튼
#    - 새 프로파일 생성 후 이름 입력
#    - 선택된 프로파일 삭제
#
# 6️⃣ 공통 매매 옵션
#    - 매수비율, 손절익절, 쿨다운 등
#
# 7️⃣ 선택된 프로파일 상세 설명창
#    - 저장된 설명 출력
#
# 8️⃣ 버튼 영역
#    - 추천 프로파일 생성
#    - 저장
#    - 자동매매 실행/종료
#
# ✅ 추가 특징
# - 사용자 친화적 테마 적용 (ttk.Style)
# - Scrollable Frame에서 Header 고정, Canvas 스크롤
# - 프로파일 생성 시 priority_order 자동 생성
# - Drag&Drop으로 편집 → strategy_config.json 저장
#
# -------------------------------------------------
#
# ✅ 저장 구조 예시
# {
#   "profiles": {
#     "default": {
#       "filter_group": [...],
#       "trigger_group": [...],
#       "trigger_mode": "OR",
#       "priority_order": [...],
#       "description": "..."
#     }
#   }
# }
#
###############################################
# ✅ 자동매매 전략 설정 GUI - 완전 통합 버전
#    (추천생성 + 편집모드 + 프로파일 추가/삭제)
# ---------------------------------------------
# ✔️ 2025년 최신 GUI 개선
# ✔️ TTK 테마
# ✔️ 스크롤 고정
# ✔️ 추천 생성 오류 방지
###############################################
#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
자동매매 전략 설정 GUI (2025년 최신)
- 루프 주기 및 연속 실패 한계 추가
- 신규 프로파일 생성/삭제
- 전략 우선순위 표시
- 잔고 현황 갱신 및 파라미터 UI 보강
- update_balances() 구현
- self.params 제거 (미사용)
"""

import sys
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, simpledialog, ttk
import subprocess
import threading

# 프로젝트 루트를 모듈 탐색 경로에 추가
BASE_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE_DIR))

# 설정 로더
from utils.config_loader import (
    load_strategy_config,
    save_strategy_config,
    load_config,
    save_config,
)

# API, 전략 함수
from core.strategy_model_b_filtering import (
    evaluate_strategies_for_symbols,  # 각 심볼에 대해 모든 전략을 평가해서 결과 리스트를 반환
    stepwise_filter_candidates,  # 전략 우선순위에 따라 최종 매수 후보를 필터링
    allocate_budget_per_candidate,  # 후보별 예산 분배
    execute_buy_orders,  # 분배된 예산으로 실제(또는 모의) 주문 실행
)
from core.bot import evaluate_and_execute_sell
from utils.telegram import send_telegram_message
from utils.bithumb_api import get_all_balances, get_all_markets
import logging

LOGGER = logging.getLogger("AutoCoin")
logging.basicConfig(level=logging.INFO)

# A/B 모델 스크립트 및 봇 경로
PROFILE_GEN_PATH = str(BASE_DIR / "core" / "strategy_model_a_profiles.py")
BOT_PATH = str(BASE_DIR / "core" / "bot.py")


# 전략 라벨 + 순번 표시용 UI
STRATEGY_LABELS = [
    ("check_rsi", "RSI 과매도 매수"),
    ("check_macd", "MACD 골드크로스"),
    ("check_ma_cross", "이동평균선 크로스"),
    ("check_bollinger", "볼린저밴드 하단 반등"),
    ("check_stochastic", "스토캐스틱 과매도 반등"),
    ("check_volume_spike", "거래량 급등 + 상승 캔들"),
    ("check_candle_reversal", "강한 반전 캔들"),
    ("market_trend_filter", "장기 추세 필터"),
    ("combined_conditions", "MACD+볼륨 동시 조건"),
    ("check_ma_slope_up", "장기 MA 우상향 추세"),
    ("check_price_breakout", "최근 고점 돌파"),
    ("check_support_rebound", "지지선 반등"),
    ("check_engulfing_bullish", "양봉 포옹형"),
    ("check_rsi_divergence", "RSI 다이버전스"),
    ("check_gap_up", "갭 상승 이후 지지"),
    ("check_mfi", "MFI 과매도 매수"),
    ("check_fibonacci", "피보나치 되돌림 매수"),
]

META_FIELDS = [
    ("trade_start_hour", "시작 시간 (시)", 0),
    ("trade_end_hour", "종료 시간 (시)", 23),
    ("cooldown_minutes", "쿨다운 (분)", 60),
    ("stop_loss_percent", "손절 (%)", -5.0),
    ("take_profit_percent", "익절 (%)", 5.0),
    ("buy_ratio_percent", "매수 비율 (%)", 50),
    ("sell_ratio_percent", "매도 비율 (%)", 50),
    ("loop_interval_seconds", "루프 간격 (초)", 60),
    ("zero_hit_limit", "연속 실패 한계 (회)", 3),
]


class StrategySelector:
    def __init__(self, root):
        self.root = root
        self.progress_window = None
        self.root.title("✅ 자동매매 전략 설정 GUI")
        self.strategy_cfg = load_strategy_config()
        self.main_cfg = load_config()

        self.profile_names = list(self.strategy_cfg.profiles.keys()) or ["default"]
        self.selected_profile_var = tk.StringVar(
            value=self.strategy_cfg.selected_profile
        )
        self.mode_var = tk.StringVar(value=self.main_cfg.mode)
        self.vars = {}
        self.meta_vars = {}

        self.root.geometry("1200x800")
        self.root.minsize(1000, 600)

        self.build_layout()
        self.apply_profile_settings()
        self.update_balances()

    def build_layout(self):
        # 그리드 비율 설정
        for i in range(4):
            self.root.rowconfigure(i, weight=1 if i > 0 else 0)
        self.root.columnconfigure(0, weight=7)
        self.root.columnconfigure(1, weight=3)

        # 헤더
        header = ttk.Frame(self.root)
        header.grid(row=0, column=0, columnspan=2, sticky="ew", padx=10, pady=5)
        prof = ttk.Frame(header)
        prof.pack(side="left")
        ttk.Label(prof, text="✔️ 프로파일:").pack(side="left")
        self.profile_cb = ttk.Combobox(
            prof,
            textvariable=self.selected_profile_var,
            values=self.profile_names,
            state="readonly",
        )
        self.profile_cb.pack(side="left")
        self.profile_cb.bind("<<ComboboxSelected>>", self.on_profile_selected)
        ttk.Label(prof, text="모드:").pack(side="left", padx=10)
        self.mode_cb = ttk.Combobox(
            prof,
            textvariable=self.mode_var,
            values=["real", "paper"],
            state="readonly",
            width=8,
        )
        self.mode_cb.pack(side="left")
        self.mode_cb.bind("<<ComboboxSelected>>", self.on_mode_changed)
        for txt, cmd in [
            ("🆕생성", self.create_new_profile),
            ("🗑삭제", self.delete_selected_profile),
            ("🔄추천", self.generate_recommended_profile),
            ("💾저장", self.save),
        ]:
            ttk.Button(prof, text=txt, command=cmd).pack(side="left", padx=2)
        for txt, cmd in [
            ("🧪테스트매수", self.test_buy),
            ("🧪테스트매도", self.test_sell),
            ("🚀실행", self.toggle_bot),
        ]:
            ttk.Button(header, text=txt, command=cmd).pack(side="right", padx=2)

        # 전략 선택
        strat = ttk.LabelFrame(self.root, text="전략 선택")
        strat.grid(row=1, column=0, sticky="nsew", padx=(10, 5), pady=5)
        for c in range(4):
            strat.columnconfigure(c, weight=1)
        for i, (k, lbl) in enumerate(STRATEGY_LABELS):
            r, c = divmod(i, 2)
            var = tk.BooleanVar()
            self.vars[k] = var
            ttk.Checkbutton(strat, text=lbl, variable=var).grid(
                row=r, column=c * 2, sticky="w"
            )
            pr = ttk.Label(strat, text="순번: -")
            pr.grid(row=r, column=c * 2 + 1, sticky="w")
            setattr(self, f"prio_{k}", pr)

        # ── 여기에 추가 ─────────────────────────
        prio_frame = ttk.LabelFrame(self.root, text="전략 우선순위 편집")
        prio_frame.grid(row=2, column=0, sticky="nsew", padx=10, pady=5)
        prio_frame.rowconfigure(0, weight=1)
        prio_frame.columnconfigure(0, weight=1)

        self.prio_listbox = tk.Listbox(prio_frame, selectmode=tk.BROWSE)
        self.prio_listbox.grid(row=0, column=0, sticky="nsew")
        sb = ttk.Scrollbar(
            prio_frame, orient="vertical", command=self.prio_listbox.yview
        )
        sb.grid(row=0, column=1, sticky="ns")
        self.prio_listbox.config(yscrollcommand=sb.set)

        # Drag&Drop 바인딩
        self.prio_listbox.bind("<Button-1>", self._drag_start)
        self.prio_listbox.bind("<B1-Motion>", self._drag_motion)
        self.prio_listbox.bind("<ButtonRelease-1>", self._drag_drop)
        # ────────────────────────────────────────

        # 공용 옵션
        opt = ttk.LabelFrame(self.root, text="공용 옵션")
        opt.grid(row=1, column=1, sticky="nsew", padx=(5, 10), pady=5)
        cols = 3
        rows = (len(META_FIELDS) + cols - 1) // cols
        for c in range(cols * 2):
            opt.columnconfigure(c, weight=1)
        for i, (k, lbl, defv) in enumerate(META_FIELDS):
            r, c = divmod(i, rows)
            var = tk.StringVar(value=str(self.strategy_cfg.meta.get(k, defv)))
            self.meta_vars[k] = var
            ttk.Label(opt, text=lbl).grid(row=r, column=c * 2, sticky="e")
            ttk.Entry(opt, textvariable=var, width=8).grid(
                row=r, column=c * 2 + 1, sticky="w"
            )

        # 설명/잔고/체결
        # 프로파일 설명
        desc_frame = ttk.LabelFrame(self.root, text="프로파일 설명")
        desc_frame.grid(row=2, column=0, sticky="nsew", padx=10, pady=(0, 10))
        self.txt_desc = tk.Text(desc_frame, height=8)
        self.txt_desc.pack(fill="both", expand=True, padx=5, pady=5)

        # 잔고 현황
        bal_frame = ttk.LabelFrame(self.root, text="잔고 현황")
        bal_frame.grid(row=2, column=1, sticky="nsew", padx=10, pady=(0, 10))
        self.txt_bal = tk.Text(bal_frame, height=8)
        self.txt_bal.pack(fill="both", expand=True, padx=5, pady=5)

        # 최근 체결
        fill_frame = ttk.LabelFrame(self.root, text="최근 체결")
        fill_frame.grid(
            row=3, column=0, columnspan=2, sticky="nsew", padx=10, pady=(0, 10)
        )
        self.txt_fill = tk.Text(fill_frame, height=5)
        self.txt_fill.pack(fill="both", expand=False, padx=5, pady=5)

    def on_profile_selected(self, e=None):
        self.strategy_cfg.selected_profile = self.selected_profile_var.get()
        save_strategy_config(cfg=self.strategy_cfg)
        self.apply_profile_settings()
        self.update_profile_info_box()

    def on_mode_changed(self, e=None):
        self.main_cfg.mode = self.mode_var.get()
        save_config(cfg=self.main_cfg)
        messagebox.showinfo("모드 변경", f"모드: {self.main_cfg.mode}")

    def apply_profile_settings(self):
        prof = self.strategy_cfg.profiles.get(self.strategy_cfg.selected_profile)
        if not prof:
            return
        # ── priority_order 기본값 채우기 ──────────────────
        if not getattr(prof, "priority_order", None):
            # STRATEGY_LABELS 순서 그대로 기본 우선순위로 설정
            prof.priority_order = [k for k, _ in STRATEGY_LABELS]
        # ────────────────────────────────────────────────

        # 체크박스 설정
        for k, var in self.vars.items():
            var.set(
                k in getattr(prof, "filter_group", [])
                or k in getattr(prof, "trigger_group", [])
            )
        # 우선순위 표시
        prio_list = getattr(prof, "priority_order", [])
        for k, _ in STRATEGY_LABELS:
            pr = getattr(self, f"prio_{k}")
            if k in prio_list:
                pr.config(text=f"순번: {prio_list.index(k)+1}")
            else:
                pr.config(text="순번: -")

        # ── Listbox 초기화 ──
        prio = getattr(prof, "priority_order", None)
        if not prio:
            # 프로파일 생성 직후나 priority_order 가 없다면 기본 순서로 채움
            prio = [k for k, _ in STRATEGY_LABELS]
            prof.priority_order = prio

        self.prio_listbox.delete(0, tk.END)
        for strat in prio:
            # STRATEGY_LABELS 에 정의된 label 텍스트까지 같이 보여주고 싶다면
            label = next(lbl for key, lbl in STRATEGY_LABELS if key == strat)
            self.prio_listbox.insert(tk.END, f"{strat} — {label}")

    def update_balances(self):
        # 1) 텍스트 위젯 초기화
        self.txt_bal.delete("1.0", tk.END)

        # 2) 실제 잔고 조회
        try:
            bal = get_all_balances()
        except Exception as e:
            self.txt_bal.insert(tk.END, f"잔고 실패: {e}")
            return

        # 3) 결과 출력
        if not bal:
            self.txt_bal.insert(tk.END, "잔고 없음")
        else:
            for symbol, info in bal.items():
                amt = info.get("balance", 0)
                # 소수점 4자리로 포맷팅
                self.txt_bal.insert(tk.END, f"{symbol}: {amt:.4f}\n")

    def update_profile_info_box(self):
        prof = self.strategy_cfg.profiles[self.strategy_cfg.selected_profile]
        self.txt_desc.delete("1.0", tk.END)
        self.txt_desc.insert(tk.END, prof.description or "(설명 없음)")

    def save(self):

        sel = self.strategy_cfg.selected_profile
        prof = self.strategy_cfg.profiles[sel]
        # 그룹 업데이트
        mid = len(STRATEGY_LABELS) // 2
        fkeys = [k for k, _ in STRATEGY_LABELS[:mid]]
        tkeys = [k for k, _ in STRATEGY_LABELS[mid:]]
        prof.filter_group = [k for k in fkeys if self.vars[k].get()]
        prof.trigger_group = [k for k in tkeys if self.vars[k].get()]
        prof.trigger_mode = prof.trigger_mode or "OR"

        # (이미 apply_profile_settings 에서 기본값 채워졌으니 그냥 저장)
        prof.priority_order = getattr(prof, "priority_order", [])

        # 메타
        self.strategy_cfg.meta = {
            k: self._parse_meta(v) for k, v in self.meta_vars.items()
        }

        # ── Listbox 에서 순서 읽어오기 ──
        new_prio = []
        for entry in self.prio_listbox.get(0, tk.END):
            # "key — Label" 형태였으니 split
            key = entry.split("—", 1)[0].strip()
            new_prio.append(key)
        prof.priority_order = new_prio

        # … meta 업데이트, 파일 저장 …
        save_strategy_config(cfg=self.strategy_cfg)
        messagebox.showinfo("저장", "설정이 저장되었습니다.")

    def create_new_profile(self):
        name = simpledialog.askstring("새 프로파일", "프로파일 이름을 입력하세요:")
        if not name or name in self.strategy_cfg.profiles:
            return
        # 새로운 프로파일은 STRATEGY_LABELS 순서 그대로 우선순위 자동 생성
        ModelClass = (
            self.strategy_cfg.__class__.model_field_schema()
            .get("profiles")
            .annotation.__args__[1]
        )
        self.strategy_cfg.profiles[name] = ModelClass(
            filter_group=[],
            trigger_group=[],
            trigger_mode="OR",
            description="",
            priority_order=[k for k, _ in STRATEGY_LABELS],
        )
        self.profile_names.append(name)
        self.profile_cb["values"] = self.profile_names
        self.selected_profile_var.set(name)
        save_strategy_config(cfg=self.strategy_cfg)
        self.apply_profile_settings()

    def delete_selected_profile(self):
        sel = self.strategy_cfg.selected_profile
        if sel == "default":
            return
        if messagebox.askyesno("삭제", f"프로파일 '{sel}'을 삭제할까요?"):
            # 1) 모델에서 삭제
            del self.strategy_cfg.profiles[sel]

            # 2) 내부 모델의 selected_profile 갱신
            new_sel = (
                self.profile_names[1] if len(self.profile_names) > 1 else "default"
            )
            self.strategy_cfg.selected_profile = new_sel

            # 3) JSON에 즉시 저장
            save_strategy_config(cfg=self.strategy_cfg)

            # 4) 콤보박스 UI 갱신
            self.profile_names.remove(sel)
            self.profile_cb["values"] = self.profile_names
            self.selected_profile_var.set(new_sel)

            # 5) 선택 변경 처리 (프로파일 세부 UI 반영)
            self.apply_profile_settings()
            self.update_profile_info_box()

    def generate_recommended_profile(self):
        def task():
            try:
                # 1) 프로그레스바 띄우기
                self.root.after(0, self.show_progress, "추천 프로파일 생성 중...")

                # 2) 실제 서브프로세스 실행
                from subprocess import PIPE

                res = subprocess.run(
                    [sys.executable, "-u", PROFILE_GEN_PATH],
                    cwd=BASE_DIR,
                    stdout=PIPE,
                    stderr=PIPE,
                    text=True,
                    encoding="utf-8",
                    errors="ignore",
                )
                if res.returncode != 0:
                    msg = [
                        f"returncode: {res.returncode}",
                        f"stdout:\n{res.stdout or '(없음)'}",
                        f"stderr:\n{res.stderr or '(없음)'}",
                    ]
                    raise RuntimeError("추천 스크립트 에러:\n" + "\n\n".join(msg))

                # 3) 결과 반영 (stdout에서 PROFILE_NAME: 파싱)
                # 3) PROFILE_NAME 파싱 시도
                output = res.stdout or ""
                name = next(
                    (
                        l.split(":", 1)[1].strip()
                        for l in output.splitlines()
                        if l.startswith("PROFILE_NAME:")
                    ),
                    None,
                )
                if not name:
                    # 디버깅용으로 stdout 전체를 띄워 줍니다.
                    raise RuntimeError(
                        "PROFILE_NAME 라인이 없습니다.\n\n"
                        f"전체 stdout:\n{output.strip() or '(없음)'}"
                    )

                # 4) UI 업데이트는 메인 스레드에서
                def on_success():
                    # 1) JSON에서 다시 읽기
                    self.strategy_cfg = load_strategy_config()
                    # 2) 프로파일 이름 리스트 갱신
                    self.profile_names = list(self.strategy_cfg.profiles.keys())
                    # 3) Combobox 값 교체
                    self.profile_cb["values"] = self.profile_names
                    # 4) 선택 변수도 새로 지정
                    self.selected_profile_var.set(name)
                    # 5) 세부 UI 반영
                    self.apply_profile_settings()
                    self.update_profile_info_box()
                    messagebox.showinfo("완료", f"추천 프로파일 생성 완료 → {name}")

                # generate_recommended_profile 안에서, 스레드가 끝나면 호출되도록…
                self.root.after(0, on_success)

            except Exception as e:
                self.root.after(0, messagebox.showerror, "추천 생성 실패", str(e))
            finally:
                self.root.after(0, self.hide_progress)

        # 백그라운드로 띄우기
        threading.Thread(target=task, daemon=True).start()

    def toggle_bot(self):
        if getattr(self, "bot_process", None) and self.bot_process.poll() is None:
            self.bot_process.terminate()
            send_telegram_message("❌ 자동매매 봇 종료")
            messagebox.showinfo("봇", "자동매매 봇을 종료했습니다.")
        else:
            self.save()
            mode = self.mode_var.get()
            self.bot_process = subprocess.Popen(
                [sys.executable, BOT_PATH, "--mode", mode], cwd=BASE_DIR
            )
            send_telegram_message(f"🤖 자동매매 봇 시작 (mode={mode})")
            messagebox.showinfo("봇", "자동매매 봇을 실행했습니다.")

    def _parse_meta(self, var):
        s = var.get()
        try:
            return int(s)
        except:
            return float(s)

    # ─── 프로그레스바 토글 ────────────────────
    def show_progress(self, message="처리 중..."):
        if self.progress_window:
            return
        pw = tk.Toplevel(self.root)
        pw.title("")
        pw.resizable(False, False)
        pw.geometry("300x60")
        ttk.Label(pw, text=message).pack(pady=5)
        pb = ttk.Progressbar(pw, mode="indeterminate")
        pb.pack(fill="x", padx=10, pady=(0, 5))
        pb.start(10)
        self.progress_window = pw

    def hide_progress(self):
        if not self.progress_window:
            return
        for child in self.progress_window.winfo_children():
            if isinstance(child, ttk.Progressbar):
                child.stop()
        self.progress_window.destroy()
        self.progress_window = None

    # 우선순위 편집 드래그앤드랍 관련함수
    def _drag_start(self, event):
        self._drag_index = self.prio_listbox.nearest(event.y)

    def _drag_motion(self, event):
        i = self.prio_listbox.nearest(event.y)
        if i != self._drag_index:
            item = self.prio_listbox.get(self._drag_index)
            # 삭제 후 다시 삽입
            self.prio_listbox.delete(self._drag_index)
            self.prio_listbox.insert(i, item)
            self._drag_index = i

    def _drag_drop(self, event):
        # 드롭 시 아무 추가 동작 불필요 (motion 단계에서 이미 옮겨짐)
        self._drag_index = None

    # ── 여기 있는 최신 디버깅 코드가 들어간 test_buy 하나만 남겨 둡니다.
    def test_buy(self):
        try:
            if self.mode_var.get() == "paper":
                portfolio = {"KRW": {"balance": 1_000_000}}
            else:
                portfolio = get_all_balances()

            symbols = get_all_markets()
            if not symbols:
                self.txt_fill.delete("1.0", tk.END)
                self.txt_fill.insert("1.0", "BUY ▶ 스킵\n(매수 대상 심볼 없음)\n")
                return

            prof = self.strategy_cfg.profiles[self.strategy_cfg.selected_profile]
            priority_order = prof.priority_order or prof.filter_group

            strategy_results = evaluate_strategies_for_symbols(
                symbols, self.strategy_cfg
            )
            candidates = stepwise_filter_candidates(
                strategy_results, priority_order, min_count=1, max_count=5
            )
            krw_balance = portfolio["KRW"]["balance"]
            buy_pct = self.strategy_cfg.meta["buy_ratio_percent"] / 100
            allocation = allocate_budget_per_candidate(candidates, krw_balance, buy_pct)

            # 디버깅 메시지
            print("▶ symbols:   ", symbols)
            print("▶ candidates:", candidates)
            print("▶ allocation:", allocation)
            self.txt_fill.delete("1.0", tk.END)
            self.txt_fill.insert("1.0", f"▶ symbols:   {symbols}\n")
            self.txt_fill.insert(tk.END, f"▶ candidates:{candidates}\n")
            self.txt_fill.insert(tk.END, f"▶ allocation:{allocation}\n")

            res = execute_buy_orders(allocation, self.mode_var.get(), LOGGER)
            print("▶ [DEBUG] res type:", type(res))
            print("▶ [DEBUG] res value:", res)

            if isinstance(res, dict) and res:
                self.txt_fill.insert(tk.END, "\nBUY ▶ 완료\n\n")
                for sym, info in res.items():
                    line = f"{sym}: price={info['price']} qty={info['quantity']} id={info.get('order_id')}\n"
                    self.txt_fill.insert(tk.END, line)
            elif isinstance(res, dict):
                self.txt_fill.insert(
                    tk.END, "\nBUY ▶ 스킵\n(매수 대상 없거나 금액 미달)\n"
                )
            # → list 로 리턴되면 우선 여기에서 잡아 주기
            elif isinstance(res, list):
                self.txt_fill.insert(tk.END, "\nBUY ▶ 후보 리스트 (리스트 리턴)\n")
                for sym in res:
                    self.txt_fill.insert(tk.END, f"{sym}\n")

            else:
                self.txt_fill.insert(tk.END, f"\nBUY ▶ 실패 (리턴값: {repr(res)})\n")

            self.update_balances()
        except Exception as e:
            messagebox.showerror("테스트매수 오류", str(e))

    def test_sell(self):
        try:
            # 1) 모든 잔고 가져오기 (딕셔너리)
            balances = get_all_balances()
            # 2) BTC 수량 확인
            btc_qty = balances.get("BTC", {}).get("balance", 0)
            if btc_qty <= 0:
                raise ValueError("BTC 잔고가 없습니다.")

            # 3) 전략 설정에서 필요한 파라미터 추출
            sl = self.strategy_cfg.meta["stop_loss_percent"]  # 손절 %
            tp = self.strategy_cfg.meta["take_profit_percent"]  # 익절 %
            sr = self.strategy_cfg.meta["sell_ratio_percent"]  # 매도 비율 %
            prof = self.strategy_cfg.profiles[self.strategy_cfg.selected_profile]

            min_conds = {  # evaluate_and_execute_sell 의 내부 .get(ticker).get("min_total") 동작을 보장
                f"KRW-{sym}": {"min_total": 5000}
                for sym, info in balances.items()
                if info.get("balance", 0) > 0
            }
            mode = self.mode_var.get()
            logger = LOGGER

            # 4) 전체 잔고 딕셔너리를 첫 인자로 넘겨야 합니다
            res = evaluate_and_execute_sell(
                balances,  # 전체 잔고 dict
                sl,  # stop_loss %
                tp,  # take_profit %
                sr,  # sell_ratio %
                min_conds,  # min_conditions 리스트
                logger,  # 로거 or log_path
                mode,  # 실행 모드 ("real" or "paper")
            )

            # 5) 결과 창 업데이트 (dict 순환 혹은 메시지)
            # ⑤ 결과 창 업데이트
            self.txt_fill.delete("1.0", tk.END)

            if isinstance(res, dict) and res:
                # ⑤-1) 실제 체결된 내역이 있으면 상세히 보여 주기
                self.txt_fill.insert("1.0", "SELL ▶ 완료\n\n")
                for sym, info in res.items():
                    line = (
                        f"{sym}: price={info['price']} "
                        f"qty={info['quantity']} "
                        f"id={info['order_id']}\n"
                    )
                    self.txt_fill.insert(tk.END, line)

            elif isinstance(res, dict) and not res:
                # ⑤-2) dict 이지만 빈 dict: "조건에 맞는 코인이 없었음"
                self.txt_fill.insert(
                    "1.0",
                    "SELL ▶ 완료\n"
                    "(조건에 맞는 코인이 없어 체결된 내역이 없습니다.)\n",
                )

            else:
                # ⑤-3) None 이나 오류 메시지 문자열이 넘어오는 경우
                self.txt_fill.insert(tk.END, f"SELL ▶ 완료 (리턴값: {repr(res)})\n")

            self.update_balances()

        except Exception as e:
            messagebox.showerror("테스트매도 오류", str(e))


if __name__ == "__main__":
    root = tk.Tk()
    StrategySelector(root)
    root.mainloop()

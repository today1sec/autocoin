import sys
import os
import uuid
import jwt
import hashlib
import time
from urllib.parse import urlencode
import requests
import json

# ✅ 경로 설정
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.bithumb_api import load_config, get_current_price

# ✅ 빗썸 API 정보
config = load_config()
ACCESS_KEY = config["api_key"]
SECRET_KEY = config["api_secret"]
API_URL = "https://api.bithumb.com"

# ✅ 빗썸 주문 엔드포인트
ORDER_ENDPOINT = "/v1/orders"


def create_auth_headers(params):
    """JWT 생성 및 헤더 반환"""
    query = urlencode(params).encode()
    m = hashlib.sha512()
    m.update(query)
    query_hash = m.hexdigest()

    payload = {
        "access_key": ACCESS_KEY,
        "nonce": str(uuid.uuid4()),
        "timestamp": round(time.time() * 1000),
        "query_hash": query_hash,
        "query_hash_alg": "SHA512",
    }

    jwt_token = jwt.encode(payload, SECRET_KEY)
    authorization_token = f"Bearer {jwt_token}"

    return authorization_token, query.decode(), query_hash, payload


def place_order_test(request_body):
    """주문 요청 및 상세 로그 출력"""
    # ✅ JWT 생성
    auth_header, query_str, query_hash, payload = create_auth_headers(request_body)
    headers = {"Authorization": auth_header, "Content-Type": "application/json"}

    # ✅ 디버그 출력
    print("\n===============================")
    print("✅ DEBUG LOG")

    print("\n✅ JWT Payload:")
    print(json.dumps(payload, indent=4))

    print("\n✅ Query (urlencode):")
    print(query_str)

    print("\n✅ Query Hash (SHA512):")
    print(query_hash)

    print("\n✅ Authorization Header:")
    print(auth_header[:50] + "...")

    print("\n✅ Request Body:")
    print(json.dumps(request_body, indent=4))

    # ✅ 실제 요청
    try:
        response = requests.post(
            API_URL + ORDER_ENDPOINT, data=json.dumps(request_body), headers=headers
        )
        print("\n✅ [RESPONSE]")
        print(f"→ Status Code: {response.status_code}")
        print(json.dumps(response.json(), indent=4, ensure_ascii=False))
    except Exception as e:
        print(f"❌ Exception: {e}")


if __name__ == "__main__":
    TICKER = "KRW-XRP"
    SIDE_LIST = ["bid", "ask"]

    # ✅ 현재가 가져오기
    current_price = get_current_price(TICKER)
    if not current_price:
        print(f"❌ 현재가 조회 실패: {TICKER}")
        sys.exit(1)

    print(f"\n✅ 현재가 {TICKER}: {current_price} KRW")

    # ✅ 테스트할 주문 수량
    units = 2.2111111

    if units * current_price >= 5000:

        formatted_units = f"{units}"

        # ✅ 매수 / 매도 각각 테스트
        for side in SIDE_LIST:
            print("\n===============================")
            print(f"✅ 테스트 시작: {side.upper()}")

            request_body = {
                "market": TICKER,
                "side": side,
                "volume": formatted_units,
                "price": f"{current_price}",
                "ord_type": "limit",
            }

            place_order_test(request_body)

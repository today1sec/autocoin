import time
import uuid
import hashlib
import jwt
import requests
from urllib.parse import urlencode

API_URL = "https://api.bithumb.com"
API_KEY = "09acb2fa6aa07dfdbc8766e56a3604fc7eb28b188ae5f6"  # 👉 여기에 본인 값 입력
API_SECRET = "MjQzMTc5M2I2YzdlMWJkOGIyZjg2OWFkN2NmN2NmZjc2MGU3NmYzNjA2Zjg3Y2IyODcxMjhjZTNmNDZjMA=="  # 👉 여기에 본인 값 입력


def get_order_chance(market: str):
    """주문 조건 조회: 최소 금액/단위"""
    endpoint = "/v1/orders/chance"
    param = {"market": market}  # e.g., "KRW-BTC"

    query = urlencode(param).encode()
    m = hashlib.sha512()
    m.update(query)
    query_hash = m.hexdigest()

    payload = {
        "access_key": API_KEY,
        "nonce": str(uuid.uuid4()),
        "timestamp": int(time.time() * 1000),
        "query_hash": query_hash,
        "query_hash_alg": "SHA512",
    }

    jwt_token = jwt.encode(payload, API_SECRET, algorithm="HS256")
    headers = {"Authorization": f"Bearer {jwt_token}"}

    try:
        res = requests.get(f"{API_URL}{endpoint}", headers=headers, params=param)
        data = res.json()
        if data.get("market") and "bid" in data["market"]:
            bid = data["market"]["bid"]
            return {
                "min_total": float(bid["min_total"]),
                "price_unit": float(bid.get("price_unit", 1)),
            }
        else:
            print(f"❌ 실패: {market} → {data.get('message')}")
            return None
    except Exception as e:
        print(f"❌ 예외 발생: {market} → {e}")
        return None


def get_krw_markets():
    """공식 KRW 마켓 리스트"""
    try:
        res = requests.get(f"{API_URL}/v1/market/all?isDetails=false")
        markets = res.json()
        return [m["market"] for m in markets if m["market"].startswith("KRW-")]
    except Exception as e:
        print("❌ 마켓 리스트 조회 실패:", e)
        return []


if __name__ == "__main__":
    print("📊 최소 주문 조건 수집 시작")
    market_list = get_krw_markets()
    print(f"총 KRW 마켓 수: {len(market_list)}")

    for m in market_list:
        print(f"🔍 {m}", end=" → ")
        info = get_order_chance(m)
        if info:
            print(f"최소 금액: {info['min_total']}원, 주문 단위: {info['price_unit']}")
        time.sleep(0.1)

if __name__ == "__main__":
    print("📊 KRW 마켓 최소 주문 조건 수집 시작")
    markets = get_krw_markets()
    result = {}

    for market in markets:
        print(f"🔍 요청 중: {market}")
        info = get_order_chance(market)
        print(f"✅ {info}")
        time.sleep(0.1)

    print("\n📦 총 수집된 마켓 수:", len(result))

import time
import uuid
import jwt
import hashlib
import requests
from urllib.parse import urlencode
import json


# 📌 config에서 API 키 불러오기
def load_config(path="C:/AutoCoin/config/config.json"):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


config = load_config()
API_KEY = config["api_key"]
API_SECRET = config["api_secret"]

# 📌 빗썸 API 2.0 base URL
BASE_URL = "https://api.bithumb.com"
ENDPOINT = "/v1/accounts"  # ← 여기 다시 검증 필요. 대부분 /v2/account/balance 또는 /v1/user/balance 형태임

# ✅ Query 생성 (없으면 빈 string)
params = {}  # GET, POST에 따라 바뀔 수 있음
query = urlencode(params).encode()

# ✅ Query hash 생성 (필수)
m = hashlib.sha512()
m.update(query)
query_hash = m.hexdigest()

# ✅ JWT Payload 구성
payload = {
    "access_key": API_KEY,
    "nonce": str(uuid.uuid4()),
    "timestamp": int(time.time() * 1000),
    "query_hash": query_hash,
    "query_hash_alg": "SHA512",
}

jwt_token = jwt.encode(payload, API_SECRET, algorithm="HS256")
authorization_token = f"Bearer {jwt_token}"

headers = {"Authorization": authorization_token, "Content-Type": "application/json"}

# ✅ 요청 전 디버그 출력
print("🔐 Payload:", payload)
print("🔑 Authorization Header:", authorization_token)

# ✅ 실제 요청
res = requests.get(BASE_URL + ENDPOINT, headers=headers, params=params)

# ✅ 응답 출력 (디버깅 포함)
print("📡 상태코드:", res.status_code)
print("📡 응답본문:", res.text)

# ✅ JSON 디코딩 (예외처리 포함)
try:
    data = res.json()
    print("\n📦 잔고 데이터:", json.dumps(data, indent=2, ensure_ascii=False))
except Exception as e:
    print("❌ JSON 파싱 실패:", e)

# ✅ 절대경로 고정 + API 1.0 인증 방식으로 복귀
# 📁 C:/AutoCoin 기준

# test_connection.py
import sys

sys.path.append("C:/AutoCoin")

from utils.bithumb_api import get_current_price, get_balance, load_config

config = load_config("C:/AutoCoin/config/config.json")
ticker = config["ticker"]
order_currency = ticker.split("_")[0]
payment_currency = ticker.split("_")[1]

print("✅ 빗썸 API 연결 테스트 시작")

price = get_current_price(ticker)
print(f"📈 현재 {ticker} 가격: {price}원")

krw_balance = get_balance("KRW")
coin_balance = get_balance(order_currency)
print(f"💰 보유 KRW 잔고: {krw_balance}")
print(f"💰 보유 {order_currency} 잔고: {coin_balance}")

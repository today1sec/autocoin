import time, hmac, hashlib, base64, requests
from urllib.parse import urlencode

api_key = "1b3e38e2ca25360ab4f5a259c91f917c"
api_secret = "d7a4f7771be5e4d834af44a42c012398"
url = "https://api.bithumb.com/info/balance"
params = {"currency": "BTC"}
nonce = str(int(time.time() * 1000))
data = "/info/balance" + chr(0) + urlencode(params) + chr(0) + nonce
signature = base64.b64encode(
    hmac.new(api_secret.encode(), data.encode(), hashlib.sha512).digest()
).decode()

headers = {
    "Api-Key": api_key,
    "Api-Sign": signature,
    "Api-Nonce": nonce,
    "Content-Type": "application/x-www-form-urlencoded",
}
print("🔍 SECRET KEY 길이:", len(api_secret))
print("🔍 SECRET KEY (repr):", repr(api_secret))
res = requests.post(url, headers=headers, data=params)
print("📡 응답:", res.json())

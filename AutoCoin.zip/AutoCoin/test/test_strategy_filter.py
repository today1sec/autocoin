# ✅ test/test_strategy_filter.py
import sys
import os

# ✅ 경로 설정
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(BASE_DIR)

import json
from utils.bithumb_api import get_all_markets
from core.strategy_handler import evaluate_strategies

# ✅ 설정 경로
STRATEGY_CONFIG_PATH = os.path.join(BASE_DIR, "config", "strategy_config.json")


# ✅ strategy_config.json 로드
def load_strategy_config():
    with open(STRATEGY_CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def main():
    print("\n====================")
    print("✅ 전략 필터링 테스트 시작")

    # ✅ 1️⃣ 모든 KRW-마켓 가져오기
    market_symbols = get_all_markets()
    print(f"✅ 총 마켓 수: {len(market_symbols)}\n")

    # ✅ 2️⃣ 전략 config 불러오기
    strategy_config = load_strategy_config()
    print(f"✅ 전략 설정 로드 완료\n")

    # ✅ 3️⃣ 전략 평가
    results = []
    for ticker in market_symbols:
        ok, strat_name, msg = evaluate_strategies(ticker, strategy_config)
        if ok:
            results.append((ticker, strat_name, msg))

    # ✅ 4️⃣ 출력
    if not results:
        print("⚠️ 전략 조건을 통과한 종목이 없습니다.")
        print("→ 테스트용 threshold 값이나 strategy_config.json 설정을 조정해보세요.\n")
    else:
        print(f"✅ 전략 통과 종목 수: {len(results)}개")
        print("✅ 심볼 리스트:")
        for r in results:
            print(f"  - {r[0]}")

        print("\n✅ 상세 결과:")
        for r in results:
            print(f"  - {r[0]} : 전략 {r[1]} → {r[2]}")

    print("\n✅ 테스트 완료")
    print("====================\n")


if __name__ == "__main__":
    main()

from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.shapes import MSO_SHAPE
from pptx.dml.color import RGBColor
import os
from pptx.enum.shapes import MSO_SHAPE
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor

# ✅ 슬라이드 내용
SLIDES_CONTENT = [
    {
        "title": "📌 빗썸 API 기반 자동매매 프로그램 설계",
        "subtitle": "→ 완전 자동화 + 전략 기반 매매",
        "notes": "발표자 : (이름)\n날짜 : (발표일)",
    },
    {
        "title": "✅ 시스템 개요",
        "content": [
            "• 빗썸 REST API 기반 완전 자동매매 프로그램",
            "• 전략 기반 매수/매도 로직",
            "• 사용자 맞춤형 전략 파라미터 설정",
            "• 최소 주문금액/단위 자동 검증",
            "• Telegram 알림 연동",
            "• GUI로 모든 설정 제어",
        ],
    },
    {
        "title": "✅ 주요 기능",
        "content": [
            "• 보유 자산 조회",
            "• 전략 평가 (RSI, MACD 등)",
            "• 포트폴리오 분배 매수",
            "• 자동 매도 (손절/익절)",
            "• 최소 주문 검증",
            "• 쿨다운/플래그 관리",
            "• GUI 기반 설정",
        ],
    },
    {
        "title": "✅ 시스템 아키텍처",
    },
    {
        "title": "✅ 메인 프로세스 흐름",
        "content": [
            "[프로그램 시작]",
            "  │",
            "  ▼",
            "[설정값 로드]",
            "  │",
            "  ▼",
            "[무한 루프 시작]",
            "  │",
            " ┌───────────────┐",
            " │ 잔고 조회       │",
            " └───────────────┘",
            "  │",
            " ┌───────────────┐",
            " │ 매도 평가/실행  │",
            " └───────────────┘",
            "  │",
            " ┌───────────────┐",
            " │ 전략 평가       │",
            " └───────────────┘",
            "  │",
            " ┌───────────────┐",
            " │ 매수 실행       │",
            " └───────────────┘",
            "  │",
            " ┌───────────────┐",
            " │ 쿨다운 관리     │",
            " └───────────────┘",
            "  │",
            "  ▼",
            "[60초 대기]",
            "  │",
            "  └── LOOP",
        ],
    },
]
SLIDES_CONTENT += [
    {
        "title": "✅ 설정파일 구조 (config.json)",
        "content": [
            "{",
            '  "meta": {',
            '    "stop_loss_percent": -5.0,',
            '    "take_profit_percent": 5.0,',
            '    "buy_ratio_percent": 50,',
            '    "sell_ratio_percent": 50,',
            '    "cooldown_minutes": 60',
            "  },",
            '  "strategies": {',
            '    "check_rsi": {',
            '      "enabled": true,',
            '      "threshold": 30',
            "    },",
            "    ...",
            "  }",
            "}",
        ],
    },
    {
        "title": "✅ 포트폴리오 분배 매수 설계",
        "content": [
            "• 전략 조건 통과 종목 수 = split_count",
            "• 잔고의 buy_ratio_percent% 예산 사용",
            "• 예산을 split_count로 균등 분배",
            "• 각 종목 예산 → 현재가 → 매수량 계산",
            "• 빗썸 최소 주문금액 조건 검증 후 주문",
            "",
            "예제:",
            "잔고: 200,000 KRW",
            "buy_ratio_percent: 50%",
            "전략 통과 종목: 4개",
            "→ 각 종목 예산 = 25,000 KRW",
        ],
    },
    {
        "title": "✅ 매도 전략 설계",
        "content": [
            "• 보유 코인 순회",
            "• 현재가 vs 평균단가 → 손익률 계산",
            "• stop_loss_percent, take_profit_percent 비교",
            "• 조건 충족 시",
            "  - 보유량 * sell_ratio_percent 만큼 매도",
            "",
            "예제:",
            "보유량: 100개",
            "sell_ratio_percent: 50%",
            "→ 매도량 = 50개",
        ],
    },
    {
        "title": "✅ 코드 설계 예시 - execute_order",
        "content": [
            "def execute_order(...):",
            "    # 1️⃣ 입력 검증",
            "    # 2️⃣ 파라미터 포맷",
            "    # 3️⃣ 빗썸 API 호출",
            "    # 4️⃣ 결과 처리 및 로그 기록",
            "",
            "• 매수/매도 공용 함수",
            "• 모든 주문 요청을 표준화",
            "• 실패 시 오류 출력 및 로깅",
        ],
    },
    {
        "title": "✅ 코드 설계 예시 - main_loop",
        "content": [
            "while True:",
            "    fetch_balances()",
            "    evaluate_and_execute_sell()",
            "    evaluate_buy_candidates()",
            "    execute_buy_orders()",
            "    manage_cooldowns()",
            "    time.sleep(60)",
            "",
            "• 무한 루프에서 단계별 함수 호출",
            "• 각 단계 독립 설계 → 디버깅/유지보수 용이",
        ],
    },
]
SLIDES_CONTENT += [
    {
        "title": "✅ GUI 화면 설계",
        "content": [
            "• 전략별 ON/OFF 체크박스",
            "• 전략별 파라미터 입력 필드",
            "• 공통 매매 옵션 입력",
            "  - 손절/익절 비율",
            "  - 매수/매도 비율",
            "• 잔고 조회 버튼",
            "• 자동매매 실행/종료 버튼",
            "",
            "→ Tkinter 기반 간단 UI",
            "→ 전략 활성화 및 파라미터 관리 지원",
        ],
    },
    {
        "title": "✅ 로그 및 Telegram 알림 설계",
        "content": [
            "• 콘솔 로그",
            "  - 단계별 진입 로그",
            "  - 잔고 출력",
            "  - 주문 파라미터",
            "  - 빗썸 응답 로그",
            "",
            "• Telegram 알림",
            "  - 봇 시작/종료 알림",
            "  - 매수/매도 성공 알림",
            "",
            "→ 실전 모니터링 필수 기능",
            "→ 실패 이유 파악 및 기록 보장",
        ],
    },
    {
        "title": "✅ 향후 확장 아이디어",
        "content": [
            "• 전략 추가 (MACD, Bollinger 등)",
            "• 텔레그램 알림 세분화",
            "• 주문 로그 CSV 저장",
            "• 백테스팅 모듈 추가",
            "• 서버 배포 / 웹 GUI 제작",
            "• 최소/최대 주문금액 범위 필터링",
            "",
            "→ 진화 가능한 설계 철학 강조",
        ],
    },
    {
        "title": "✅ Q&A",
        "content": [
            "질문과 의견을 자유롭게 주세요!",
            "",
            "→ 향후 개선 아이디어 공유",
            "→ 전략별 피드백 토론 가능",
            "",
            "✅ 감사합니다!",
        ],
    },
]

print("✅ 코드 실행 시작!")

# ✅ 프레젠테이션 생성
prs = Presentation()

# ✅ 슬라이드별 생성
for slide_data in SLIDES_CONTENT:
    if "subtitle" in slide_data:
        # ✅ 제목 슬라이드
        slide_layout = prs.slide_layouts[0]
        slide = prs.slides.add_slide(slide_layout)
        slide.shapes.title.text = slide_data["title"]
        slide.placeholders[1].text = slide_data["subtitle"]
    else:
        content = slide_data.get("content", [])
        title = slide_data["title"]

        # ✅ 너무 길면 자동으로 분할
        MAX_LINES_PER_SLIDE = 15
        if len(content) > MAX_LINES_PER_SLIDE:
            # ➜ 분할
            for i in range(0, len(content), MAX_LINES_PER_SLIDE):
                sub_content = content[i : i + MAX_LINES_PER_SLIDE]
                part_num = (i // MAX_LINES_PER_SLIDE) + 1
                new_title = f"{title} (Part {part_num})"

                slide_layout = prs.slide_layouts[1]
                slide = prs.slides.add_slide(slide_layout)
                slide.shapes.title.text = new_title
                body_shape = slide.shapes.placeholders[1]
                tf = body_shape.text_frame

                # 글자 크기 결정
                num_lines = len(sub_content)
                if num_lines <= 8:
                    font_size = Pt(24)
                elif num_lines <= 15:
                    font_size = Pt(20)
                else:
                    font_size = Pt(16)

                for line in sub_content:
                    p = tf.add_paragraph()
                    p.text = line
                    p.level = 0

                    if p.runs:
                        run = p.runs[0]
                        run.font.size = font_size
                        run.font.bold = True
                        run.font.color.rgb = RGBColor(0, 102, 204)
        else:
            # ✅ 한 슬라이드에 그대로 넣기
            slide_layout = prs.slide_layouts[1]
            slide = prs.slides.add_slide(slide_layout)
            slide.shapes.title.text = title
            body_shape = slide.shapes.placeholders[1]
            tf = body_shape.text_frame

            # 글자 크기 결정
            num_lines = len(content)
            if num_lines <= 8:
                font_size = Pt(24)
            elif num_lines <= 15:
                font_size = Pt(20)
            else:
                font_size = Pt(16)

            for line in content:
                p = tf.add_paragraph()
                p.text = line
                p.level = 0

                if p.runs:
                    run = p.runs[0]
                    run.font.size = font_size
                    run.font.bold = True
                    run.font.color.rgb = RGBColor(0, 102, 204)


# ✅ 새로운 아키텍처 슬라이드 추가
slide_layout = prs.slide_layouts[5]  # 빈 슬라이드 레이아웃
slide = prs.slides.add_slide(slide_layout)

# ✅ 제목 추가
title_shape = slide.shapes.title
if title_shape:
    title_shape.text = "✅ 시스템 아키텍처"

# ✅ 각 박스 내용
architecture_boxes = [
    "✅ GUI (Tkinter)\n전략 선택 / 설정\n자동매매 실행 버튼",
    "bot.py\n(메인루프)\n(subprocess 호출)",
    "trade_executor.py\n- execute_order()",
    "bithumb_api.py\n- 주문 실행\n- 잔고 조회",
]

# ✅ 위치 조정
left = Inches(1)
top = Inches(1.5)
width = Inches(5.5)
height = Inches(1)

gap = Inches(0.3)  # 박스 간격

for text in architecture_boxes:
    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, left, top, width, height)
    shape.fill.solid()
    shape.fill.fore_color.rgb = RGBColor(242, 242, 242)  # 연회색
    shape.line.color.rgb = RGBColor(0, 102, 204)  # 파란 테두리
    shape.text_frame.text = text

    # 텍스트 서식
    for paragraph in shape.text_frame.paragraphs:
        for run in paragraph.runs:
            run.font.size = Pt(18)
            run.font.bold = True
            run.font.color.rgb = RGBColor(0, 102, 204)

    top += height + gap

print("✅ 모든 슬라이드 생성 완료!")

# ✅ 파일 경로 → 스크립트 위치 기준으로 저장
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
OUT_PATH = os.path.join(SCRIPT_DIR, "Bithumb_Auto_Trading_Design.pptx")

try:
    prs.save(OUT_PATH)
    print(f"✅ PPTX 파일 생성 완료! → {OUT_PATH}")
except Exception as e:
    print(f"❌ 오류 발생: {e}")

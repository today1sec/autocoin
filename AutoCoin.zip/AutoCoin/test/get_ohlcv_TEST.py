import sys
import os
import json
import pandas as pd

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.strategy_handler import evaluate_strategies
from utils.bithumb_api import get_ohlcv
from core.strategy import check_rsi

# 🔧 전략 설정 불러오기
config_path = os.path.join(os.path.dirname(__file__), "../config/strategy_config.json")
with open(config_path, "r", encoding="utf-8") as f:
    default_strategy_config = json.load(f)

# 테스트 대상 티커
TICKER = "KRW-BTC"
CONFIG_PATH = "./config/strategy_config.json"


# ✅ 전략 설정 로딩
with open(CONFIG_PATH, "r", encoding="utf-8") as f:
    strategy_config = json.load(f)

# ✅ 캔들 데이터 불러오기
df = get_ohlcv(TICKER, interval="24h", count=100)
print(f"\n📊 [OHLCV Data Preview for {TICKER}]\n{df.head()}")


# ✅ 전략 평가 실행
print("\n🔍 [Evaluating Strategies...]\n")
is_match, strat_name, reason = evaluate_strategies(
    ticker=TICKER, config=strategy_config, interval="24h", count=100
)


# ✅ 결과 출력
if is_match:
    print(f"✅ 전략 매칭됨 → 전략명: {strat_name}, 사유: {reason}")
else:
    print(f"❌ 조건에 맞는 전략 없음 → 사유: {reason}")

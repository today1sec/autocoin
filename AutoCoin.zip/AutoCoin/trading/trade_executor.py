# ✅ 💰 trade_executor.py 설계 (주석 버전) - 통합 주문 함수

# -------------------------------------------------
# ✅ execute_order 함수 (매수/매도 공용)
# -------------------------------------------------
# - 입력 파라미터:
#     - ticker: 심볼명 (ex: "KRW-BTC")
#     - side: 주문 방향 ("bid" = 매수, "ask" = 매도)
#     - amount: 주문 수량
#     - price: 주문 가격
#     - min_total: 최소 주문 금액 조건
#     - logger: utils.logger.setup_logger 로 생성된 Logger 인스턴스
#     - mode: 실행 모드 ("real" or "paper")
#     - retries: 재시도 횟수
#     - retry_delay: 재시도 간격(초)
#
# - 처리 단계:
#   1️⃣ 주문 전 검증
#       - amount > 0 확인
#       - amount * price ≥ min_total 확인
#       - 조건 미달 시 주문 스킵
#   2️⃣ 주문 수량 포맷팅
#       - 소수점 최대 8자리로 제한
#   3️⃣ 주문 파라미터 구성 (로그 출력용)
#   4️⃣ 주문 API 호출 + 재시도
#   5️⃣ 주문 결과 처리 (로그 기록)
# -------------------------------------------------

import time
import logging
from utils.bithumb_api import place_order, get_min_order_amounts
from utils.logger import setup_logger  # setup_logger 로 초기 Logger 생성


def validate_order_conditions(
    amount: float, price: float, min_total: float, logger: logging.Logger
) -> bool:
    """
    ✅ 주문 전 검증 함수
    - 수량이 0 이하인지 확인
    - 총액이 최소 주문금액 이상인지 확인
    """
    if amount <= 0:
        logger.warning(f"⚠️ 주문 스킵: 수량이 0 이하 (amount={amount})")
        return False

    total_cost = amount * price
    if total_cost < min_total:
        logger.warning(
            f"⚠️ 주문 스킵: 총액 미달 (total={total_cost:.4f} < min_total={min_total})"
        )
        return False

    return True


def format_volume(amount: float) -> str:
    """
    ✅ 주문 수량을 문자열로 변환
    - 소수점 자리수는 최대 8자리까지 제한
    """
    try:
        return f"{round(amount, 8)}"
    except Exception:
        return str(int(amount))


def build_order_params(ticker: str, side: str, volume_str: str, price: float) -> dict:
    """
    ✅ 빗썸 주문 API 파라미터 딕셔너리 생성
    """
    return {
        "market": ticker,
        "side": side,
        "volume": volume_str,
        "price": price,
        "ord_type": "limit",
    }


def send_order(
    ticker: str,
    side: str,
    volume_str: str,
    price: float,
    mode: str,
    logger: logging.Logger,
) -> bool:
    """
    ✅ 주문 API 호출 및 결과 반환
    - 모의주문(paper)일 경우 바로 True 리턴
    """
    if mode != "real":
        logger.info(f"🟢 [모의주문] {side.upper()} {ticker} {volume_str} @ {price}")
        return True

    result = place_order(ticker=ticker, side=side, amount=volume_str, price=price)
    if result and result.get("uuid"):
        logger.info(f"✅ 주문 성공 → {result}")
        return True
    else:
        logger.error(f"❌ 주문 실패 → {result}")
        return False


def handle_order_result(
    success: bool,
    ticker: str,
    side: str,
    price: float,
    volume_str: str,
    logger: logging.Logger,
    mode: str,
    rsi: str = "-",
):
    """
    ✅ 주문 결과 처리
    - 성공 시 info, 실패 시 error 로그
    """
    trade_type = "[실전]" if mode == "real" else "[모의]"
    if success:
        logger.info(f"{trade_type} {side.upper()} {ticker} {volume_str} @ {price}")
    else:
        logger.error(f"{trade_type} {side.upper()} {ticker} {volume_str} @ {price}")


def execute_order(
    ticker: str,
    side: str,
    amount: float,
    price: float,
    min_total: float,
    logger: logging.Logger,
    mode: str,
    retries: int = 3,
    retry_delay: float = 1.0,
) -> bool:
    """
    ✅ 메인 주문 실행 함수 (통합)
    1) validate_order_conditions
    2) format_volume
    3) build_order_params (로그 출력용)
    4) send_order + 재시도
    5) handle_order_result
    """
    # 1️⃣ 주문 전 검증
    if not validate_order_conditions(amount, price, min_total, logger):
        return False

    # 2️⃣ 주문 수량 포맷팅
    volume_str = format_volume(amount)

    # 3️⃣ 주문 파라미터 구성 및 로그
    params = build_order_params(ticker, side, volume_str, price)
    logger.info(f"✅ 주문 파라미터 → {params}")

    # 4️⃣ API 호출 & 재시도
    for attempt in range(1, retries + 1):
        success = send_order(ticker, side, volume_str, price, mode, logger)
        handle_order_result(success, ticker, side, price, volume_str, logger, mode)
        if success:
            return True
        if attempt < retries:
            logger.warning(
                f"{ticker} 주문 재시도 {attempt}/{retries} (대기 {retry_delay}s)"
            )
            time.sleep(retry_delay)

    # 5️⃣ 모든 시도 실패
    logger.error(f"{ticker} 주문 완전 실패 after {retries} attempts")
    return False

# state_manager.py # 파일 설명:
# - 회복적 규칙을 위해 상태을 감소하는 전문 구조
# - 하루 1회 개정을 위한 플래그 관리
# - 시간 커뒤용 (어린 반드 개발에서는 TTL 또는 redis 활용)

import time
from datetime import datetime, timedelta
from utils.config_loader import load_config, save_config

# 쿨다운 정보 (매수/매도 한번 실행 후 영역 제외)
cooldowns = {}

# 일 종류 반드 또는 어린 TTL과 같이
COOLDOWN_SECONDS = 5 * 60  # 5분
FLAG_EXPIRE_HOURS = 24


def is_on_cooldown(ticker: str, action: str):
    """
    매수/매도 쿨다운 확인
    """
    key = f"{ticker}_{action}"
    expire_at = cooldowns.get(key)
    if not expire_at:
        return False
    return time.time() < expire_at


def set_cooldown(ticker: str, action: str):
    key = f"{ticker}_{action}"
    cooldowns[key] = time.time() + COOLDOWN_SECONDS


def reset_all_flags():
    """
    내년도 계속 복잡하게 사용할 경우
    일과 같은 다른 기준으로 관리해야 함
    """
    global trade_flags
    trade_flags = {}


def clear_expired_cooldowns():
    """
    쿨다운 완료된 항목 차단 제거
    """
    now = time.time()
    expired_keys = [k for k, v in cooldowns.items() if v < now]
    for k in expired_keys:
        del cooldowns[k]


def is_traded_today(ticker: str, action: str = None):
    flags = get_trade_flags()
    today = datetime.now().date().isoformat()
    key = f"{ticker}_{action}"
    return flags.get(key) == today


def get_trade_flags():
    config = load_config()
    return config.get("trade_flags", {})


def set_trade_flag(ticker: str):
    trade_flags[ticker] = datetime.now().date()


def save_trade_flags(flags):
    config = load_config()
    config["trade_flags"] = flags
    save_config(config)


def set_trade_flag(ticker, action):
    flags = get_trade_flags()
    today = datetime.now().date().isoformat()
    key = f"{ticker}_{action}"
    flags[key] = today
    save_trade_flags(flags)

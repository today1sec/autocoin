# bithumb_api.py (빗썸 API 연동 유틸 - 주문, 잔고, 시세, 최소 주문 단위 포함)

"""
📌 이 파일의 역할 (arg):
- ✅ 설정 로딩: config.json에서 API 키/시크릿 로딩
- 💰 잔고 조회: 전체 잔고(get_all_balances), 단일 잔고(get_balance)
- 📈 현재가 조회: 특정 종목 시세 조회 (get_current_price)
- 📦 주문 실행: 지정가 매수/매도 실행 (place_order)
- ⚠️ 주문 실패 시 사유 출력 ('invalid_volume' 포함)
- 🧾 최소 주문 조건 조회: 공용 API 기반 min_total 기준 계산 (get_min_order_amounts)
"""

import time
import uuid
import jwt
import hashlib
import requests
import json
from urllib.parse import urlencode
import pandas as pd


# ✅ API Key는 config.json 기준
def load_config(path="C:/AutoCoin/config/config.json"):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


config = load_config()
API_URL = "https://api.bithumb.com"
API_KEY = config["api_key"]
API_SECRET = config["api_secret"]

# ✅ Bithumb API Endpoint 목록
ENDPOINTS = {
    # 🔓 PUBLIC (인증 불필요: 시세, 마켓 정보 등)
    "market_all": "/v1/market/all",  # 전체 마켓 리스트 (KRW, BTC, USDT 등)
    "ticker": "/v1/ticker",  # 전체 현재가 정보
    "candles_days": "/v1/candles/days",  # 일봉 캔들 데이터
    "candles_months": "/v1/candles/months",  # 월봉 캔들 데이터
    "candles_minutes": "/v1/candles/minutes/{interval}",  # 분봉 캔들 데이터 (1, 3, 5, 10, 30, 60, 240)
    "orderbook": "/v1/orderbook",  # 실시간 호가 정보
    "transaction_history": "/v1/trades/ticks",  # 체결 내역 조회
    "assets_status": "/v1/market/virtual_asset_warning",  # 투자 유의 종목 (급등락 경고)
    # 🔒 PRIVATE (JWT 인증 필요: 주문, 잔고 등)
    "order_chance": "/v1/orders/chance",  # 주문 가능 여부 (최소 금액, 잔고 등)
    "place_order": "/v1/orders",  # 주문 실행 (매수/매도)
    "cancel_order": "/v1/order/cancel",  # 주문 취소
    "order_detail": "/v1/order",  # 단일 주문 조회
    "order_list": "/v1/orders",  # 주문 리스트 조회
    "all_balances": "/v1/accounts",  # 전체 보유 잔고 조회
    "balance": "/v1/account/balance",  # 개별 자산 잔고 조회
    "withdraw_fee": "/v1/withdraw/fee",  # 출금 수수료 조회
}


# ✅ JWT 토큰 생성 유틸
def _generate_jwt(params):
    query = urlencode(params).encode()
    m = hashlib.sha512()
    m.update(query)
    query_hash = m.hexdigest()

    payload = {
        "access_key": API_KEY,
        "nonce": str(uuid.uuid4()),
        "timestamp": round(time.time() * 1000),
        "query_hash": query_hash,
        "query_hash_alg": "SHA512",
    }

    jwt_token = jwt.encode(payload, API_SECRET)
    headers = {
        "Authorization": f"Bearer {jwt_token}",
        "Content-Type": "application/json",
    }

    return payload, headers


# ✅ 주문 실행
def place_order(ticker, side, price, volume):
    endpoint = ENDPOINTS["place_order"]
    body = {
        "market": ticker,
        "side": side,
        "volume": str(volume),
        "price": str(price),
        "ord_type": "limit",
    }
    payload, headers = _generate_jwt(body)
    try:
        res = requests.post(API_URL + endpoint, headers=headers, json=body)
        return res.json()
    except Exception as e:
        print("❌ 주문 실패:", e)
        return {"error": str(e)}


# ✅ 잔고 조회 (전체)
def get_all_balances():
    endpoint = ENDPOINTS["all_balances"]
    payload, headers = _generate_jwt({})
    try:
        res = requests.get(API_URL + endpoint, headers=headers)
        data = res.json()
        if not isinstance(data, list):
            print("❌ 잔고 형식 오류:", data)
            return {}
        result = {
            item["currency"].upper(): {
                "balance": float(item["balance"]),
                "avg_buy_price": float(item["avg_buy_price"]),
            }
            for item in data
        }
        return result
    except Exception as e:
        print("❌ 잔고 조회 실패:", e)
        return {}


# ✅ 단일 잔고
def get_balance(currency):
    result = get_all_balances().get(currency.upper())
    return result["balance"] if result else 0.0


# ✅ 현재가 조회
def get_current_price(ticker):
    try:
        url = f"{API_URL}{ENDPOINTS['ticker']}?markets={ticker}"
        resp = requests.get(url)
        result = resp.json()

        # ✅ CASE 2: list 형식 (새 응답 구조)
        if isinstance(result, list) and len(result) > 0 and isinstance(result[0], dict):
            return float(result[0].get("trade_price"))

        else:
            print(f"❌ 응답 형식 이상함: {result}")
            return None

    except Exception as e:
        print(f"❌ 현재가 조회 실패: {ticker} - {e}")
        return None


# ✅ 캔들 조회 (interval 대응)
def get_ohlcv(ticker, interval="24h", count=10):
    # print(
    #     f"📌 get_ohlcv 호출됨 → ticker: {ticker}, interval: {interval}, count: {count}, type: {type(ticker)}"
    # )
    try:
        # ⏱️ 캔들 종류 선택
        if interval.endswith("h") or interval == "24h":
            endpoint = ENDPOINTS["candles_days"]
        elif interval == "month":
            endpoint = ENDPOINTS["candles_months"]
        else:
            minutes = interval.replace("m", "")
            endpoint = ENDPOINTS["candles_minutes"].format(interval=minutes)

        url = f"{API_URL}{endpoint}"
        params = {"market": ticker, "count": count}
        res = requests.get(url, params=params)
        data = res.json()

        # ❌ 전체 오류 응답 제거
        if isinstance(data, dict) and "error" in data:
            raise ValueError(f"❌ 캔들 응답 오류: {data}")

        # ✅ 리스트 내 개별 오류 제거
        if isinstance(data, list):
            data = [
                item for item in data if isinstance(item, dict) and "error" not in item
            ]

        # ✅ 형식 확인 후 DataFrame 변환
        if isinstance(data, list) and isinstance(data[0], dict):
            df = pd.DataFrame(data)

            # ✅ 컬럼 이름 매핑
            rename_map = {
                "candle_date_time_kst": "timestamp",
                "opening_price": "open",
                "high_price": "high",
                "low_price": "low",
                "trade_price": "close",
                "candle_acc_trade_volume": "volume",
                "candle_acc_trade_price": "value",
                "timestamp": "timestamp_2",
            }

            df = df.rename(
                columns={k: v for k, v in rename_map.items() if k in df.columns}
            )

            # ✅ 필요한 컬럼만 추출
            expected = ["timestamp", "open", "close", "high", "low", "volume", "value"]
            df = df[[col for col in expected if col in df.columns]]

            df = df.astype(float, errors="ignore")  # float 변환 오류 무시
            df = df[::-1].reset_index(drop=True)
            return df

        raise ValueError(f"❌ 캔들 응답 형식 오류: {data}")

    except Exception as e:
        print(f"❌ 예외 발생 (캔들 조회 실패: {ticker}) - {e}")
        return pd.DataFrame()


# ✅ 호가 정보 조회
def get_orderbook(ticker):
    try:
        url = f"{API_URL}{ENDPOINTS['orderbook']}"
        res = requests.get(url, params={"markets": ticker})
        data = res.json()
        return data[ticker]
    except Exception as e:
        print(f"❌ 호가 정보 조회 실패: {ticker} - {e}")
        return None


# ✅ 체결 내역 조회
def get_transaction_history(ticker, count=10):
    try:
        url = f"{API_URL}{ENDPOINTS['transaction_history']}"
        res = requests.get(url, params={"market": ticker, "count": count})
        data = res.json()
        return data
    except Exception as e:
        print(f"❌ 체결 내역 조회 실패: {ticker} - {e}")
        return None


# ✅ 위험 종목 조회
def get_risk_alerts():
    try:
        url = f"{API_URL}{ENDPOINTS['assets_status']}"
        res = requests.get(url)
        return res.json()
    except Exception as e:
        print("❌ 위험 종목 상태 조회 실패:", e)
        return None


# ✅ 주문 가능 조건 조회
def get_order_chance(ticker):
    endpoint = ENDPOINTS["order_chance"]
    params = {"market": ticker}
    payload, headers = _generate_jwt(params)
    try:
        res = requests.get(API_URL + endpoint, headers=headers, params=params)
        data = res.json()
        if data.get("market") and "bid" in data["market"]:
            bid = data["market"]["bid"]
            return {
                "min_total": float(bid["min_total"]),
                "price_unit": float(bid.get("price_unit", 1)),
            }
    except Exception as e:
        print(f"❌ 주문 조건 조회 실패: {ticker} - {e}")
    return None


# ✅ 최소 주문 금액 조건 여러 종목 처리
def get_min_order_amounts(filtered_markets: list[str]):
    result = {}
    for raw_market in filtered_markets:
        if not raw_market.startswith("KRW-"):
            continue
        info = get_order_chance(raw_market)
        if info:
            result[raw_market] = info
    return result


# ✅ 전체 마켓 심볼 가져오기 (KRW-* 전용)
def get_all_markets():
    try:
        url = f"{API_URL}{ENDPOINTS['market_all']}"
        res = requests.get(url, params={"isDetails": "false"})
        data = res.json()

        market_symbols = []
        if isinstance(data, list):
            for item in data:
                market = item.get("market")
                if market and market.startswith("KRW-"):
                    market_symbols.append(market)
        return market_symbols

    except Exception as e:
        print(f"❌ 마켓 리스트 조회 실패: {e}")
        return []

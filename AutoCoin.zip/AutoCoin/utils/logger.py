# File: AutoCoin/utils/logger.py

import os
import logging
import json
from logging import Logger
from pathlib import Path
from typing import Any, Dict


def setup_logger(log_path: str) -> Logger:
    """
    로거를 설정하고 반환합니다.
    - log_path: 로그 파일 기본 경로(디렉터리 포함, 파일명 제외)
      예: "logs/trade_log" → "logs/trade_log.csv" 및 "logs/trade_log.jsonl" 생성
    """
    # 디렉터리 생성
    base = Path(log_path)
    base.parent.mkdir(parents=True, exist_ok=True)

    logger = logging.getLogger("AutoCoin")
    logger.setLevel(logging.INFO)
    logger.propagate = False  # 중복 출력 방지

    # --- CSV 핸들러 ---
    csv_handler = logging.FileHandler(f"{log_path}.csv", encoding="utf-8")
    csv_handler.setLevel(logging.INFO)
    csv_fmt = logging.Formatter("%(asctime)s,%(levelname)s,%(message)s")
    csv_handler.setFormatter(csv_fmt)
    logger.addHandler(csv_handler)

    # --- JSON-lines 핸들러 ---
    json_handler = logging.FileHandler(f"{log_path}.jsonl", encoding="utf-8")
    json_handler.setLevel(logging.INFO)

    # 커스텀 포맷터로 record를 JSON으로 변환
    class JSONFormatter(logging.Formatter):
        def format(self, record: logging.LogRecord) -> str:
            payload: Dict[str, Any] = {
                "time": self.formatTime(record),
                "level": record.levelname,
                "message": record.getMessage(),
            }
            return json.dumps(payload, ensure_ascii=False)

    json_handler.setFormatter(JSONFormatter())
    logger.addHandler(json_handler)

    # --- 콘솔 출력 핸들러 (선택) ---
    console = logging.StreamHandler()
    console.setLevel(logging.WARNING)
    console_fmt = logging.Formatter("[%(levelname)s] %(message)s")
    console.setFormatter(console_fmt)
    logger.addHandler(console)

    return logger


# ======= 실제 사용 예시 =======
# from utils.logger import setup_logger
# logger = setup_logger("logs/trade_log")
#
# # 정상 거래 기록
# logger.info("KRW-BTC,BUY,0.001,45000000")
#
# # 재시도 또는 경미한 경고
# logger.warning("KRW-ETH 주문 재시도 1/3")
#
# # 치명적 오류
# logger.error("API 연결 실패: timeout")

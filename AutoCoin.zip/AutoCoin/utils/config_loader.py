# File: utils/config_loader.py

import json
from pathlib import Path
from pydantic import BaseModel, Field, validator
from typing import List

# 프로젝트 루트 디렉터리
BASE_DIR = Path(__file__).resolve().parents[1]


class MainConfig(BaseModel):
    api_key: str = Field(..., description="거래소 API Key")
    api_secret: str = Field(..., description="거래소 API Secret")
    mode: str = Field(..., description="실행 모드 (real 또는 paper)")
    strategy_config_path: Path = Field(..., description="전략 설정 파일 경로")
    log_path: Path = Field(
        ..., description="로그 파일 저장 경로 (base path, 확장자 제외)"
    )
    telegram_bot_token: str = Field(..., description="텔레그램 봇 토큰")
    telegram_chat_id: str = Field(..., description="텔레그램 채팅 ID")
    loop_interval_seconds: int = Field(..., ge=1, description="루프 대기 시간 (초)")
    zero_hit_limit: int = Field(
        ..., ge=1, description="연속 매수 후보 0회 시 프로파일 전환 임계치"
    )

    @validator("strategy_config_path", "log_path", pre=True)
    def make_absolute(cls, v):
        p = Path(v)
        # 절대경로가 아니면 BASE_DIR 기준으로 변환
        return (BASE_DIR / p) if not p.is_absolute() else p


class StrategyProfile(BaseModel):
    filter_group: list[str] = Field(..., description="필터 그룹 전략 키 리스트")
    trigger_group: list[str] = Field(..., description="트리거 그룹 전략 키 리스트")
    trigger_mode: str = Field(..., description="트리거 결합 모드 (AND 또는 OR)")
    description: str = Field(..., description="프로파일 상세 설명")
    priority_order: List[str] = []


class StrategyConfig(BaseModel):
    # 개별 전략의 enabled 여부
    check_rsi: dict[str, bool]
    check_macd: dict[str, bool]
    check_ma_cross: dict[str, bool]
    check_bollinger: dict[str, bool]
    check_stochastic: dict[str, bool]
    check_volume_spike: dict[str, bool]
    check_candle_reversal: dict[str, bool]
    market_trend_filter: dict[str, bool]
    combined_conditions: dict[str, bool]
    check_ma_slope_up: dict[str, bool]
    check_price_breakout: dict[str, bool]
    check_support_rebound: dict[str, bool]
    check_engulfing_bullish: dict[str, bool]
    check_rsi_divergence: dict[str, bool]
    check_gap_up: dict[str, bool]
    check_mfi: dict[str, bool]
    check_fibonacci: dict[str, bool]

    meta: dict[str, int | float] = Field(..., description="공통 메타 파라미터")
    selected_profile: str = Field(..., description="현재 선택된 프로파일 이름")
    profiles: dict[str, StrategyProfile] = Field(..., description="프로파일별 설정")

    """ 
    @validator("selected_profile")
    def validate_selected_profile(cls, v, values):
        profiles = values.get("profiles", {})
        if v not in profiles:
            raise ValueError(
                f"선택된 프로파일 '{v}'이 profiles에 없습니다: {list(profiles)}"
            )
        return v
    """


def load_config(path: Path = None) -> MainConfig:
    """
    메인 설정(config.json)을 로드하여 MainConfig 객체로 반환.
    path 인자를 주지 않으면 BASE_DIR/config/config.json 사용.
    """
    cfg_path = path or (BASE_DIR / "config" / "config.json")
    data = json.loads(cfg_path.read_text(encoding="utf-8"))
    return MainConfig(**data)


def save_config(path: Path = None, cfg: MainConfig | dict = None):
    """
    MainConfig 객체 또는 dict를 JSON으로 저장.
    path 인자를 주지 않으면 BASE_DIR/config/config.json 사용.
    """
    cfg_path = path or (BASE_DIR / "config" / "config.json")
    payload = (
        cfg if isinstance(cfg, dict) else json.loads(cfg.model_dump_json(indent=2))
    )
    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    cfg_path.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8"
    )


""" 
def load_strategy_config(path: Path = None) -> StrategyConfig:
   
    cfg_path = path or (BASE_DIR / "config" / "strategy_config.json")
    data = json.loads(cfg_path.read_text(encoding="utf-8"))
    return StrategyConfig(**data)
 """


def load_strategy_config(path: Path = None) -> StrategyConfig:
    """
    전략 설정(strategy_config.json)을 로드하여 StrategyConfig 객체로 반환.
    path 인자를 주지 않으면 BASE_DIR/config/strategy_config.json 사용.
    """
    cfg_path = path or (BASE_DIR / "config" / "strategy_config.json")
    text = cfg_path.read_text(encoding="utf-8")
    # print("🔍 Loaded JSON from", cfg_path)
    data = json.loads(text)
    """ print(
        "🔍 data['profiles'] =", data.get("profiles")
    )  # 여기가 빈 {}인가, 실제 값이 들어있나 확인 """
    return StrategyConfig(**data)


def save_strategy_config(path: Path = None, cfg: StrategyConfig | dict = None):
    """
    StrategyConfig 객체 또는 dict를 JSON으로 저장.
    path 인자를 주지 않으면 BASE_DIR/config/strategy_config.json 사용.
    """
    cfg_path = path or (BASE_DIR / "config" / "strategy_config.json")
    payload = (
        cfg if isinstance(cfg, dict) else json.loads(cfg.model_dump_json(indent=2))
    )
    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    cfg_path.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8"
    )

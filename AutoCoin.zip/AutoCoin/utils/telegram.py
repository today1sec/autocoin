# utils/telegram.py

import requests
import json
import os


# ✅ config.json 로딩
def load_config(path="C:/AutoCoin/config/config.json"):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


config = load_config()
BOT_TOKEN = config.get(
    "telegram_bot_token", "8077885395:AAGSziMKUZqlZq7Tbzhyzjgxel5ReSWGw00"
)
CHAT_ID = config.get("telegram_chat_id", "8099460048")


def send_telegram_message(text: str) -> bool:
    if not BOT_TOKEN or not CHAT_ID:
        print(
            "❌ 텔레그램 설정 누락: config.json에 'telegram_bot_token', 'telegram_chat_id'가 필요합니다."
        )
        return False

    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": CHAT_ID,
        "text": text,
    }
    try:
        res = requests.post(url, data=payload)
        return res.status_code == 200
    except Exception as e:
        print(f"❌ 텔레그램 전송 실패: {e}")
        return False
